package io.swagger.v3.oas.annotations;
import java.lang.annotation.*;
@Retention(RetentionPolicy.RUNTIME) public @interface Operation { String summary() default ""; }
