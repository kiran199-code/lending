package org.springframework.web.bind.annotation;
import java.lang.annotation.*;
@Retention(RetentionPolicy.RUNTIME) public @interface RequestHeader { String value() default ""; boolean required() default true; }
