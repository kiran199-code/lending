#!/bin/bash
# Stub-compile IAM main (+tests when present). SecurityConfig (HttpSecurity DSL) is excluded: it needs the real spring-security API.
M=/home/claude/iamsvc/lending-iam-service
OUT=/home/claude/iamsvc/out; rm -rf $OUT; mkdir -p $OUT
L=/opt/gradle-8.14.3/lib
CP=$(ls $L/jackson-{core,databind,annotations}-2.16.1.jar $L/jackson-datatype-jsr310-2.16.1.jar $L/jackson-datatype-jdk8-2.16.1.jar $L/slf4j-api-1.7.36.jar | tr '\n' ':')
find $M/src/main/java /home/claude/iamsvc/stubs $M/src/test/java -name '*.java' ! -name '*IT.java' ! -name SecurityConfig.java > /tmp/iam_src.txt
javac -Xlint:all -Xlint:-processing -Xlint:-serial -d $OUT -cp "$CP" @/tmp/iam_src.txt 2>&1 | grep -v JAVA_TOOL_OPTIONS | head -${LINES_MAX:-150}
echo "javac exit: ${PIPESTATUS[0]}"
