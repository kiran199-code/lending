package org.springframework.web.bind;
import java.util.List;
public class MethodArgumentNotValidException extends RuntimeException {
  public static class FieldError { public String getField(){return "";} public String getDefaultMessage(){return "";} }
  public static class BindingResult { public List<FieldError> getFieldErrors(){return List.of();} }
  public BindingResult getBindingResult(){return new BindingResult();} }
