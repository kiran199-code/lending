package org.springframework.transaction.support;
import org.springframework.transaction.*;
import java.util.function.Supplier;
public class TransactionTemplate {
  /** Local test hook: the Postgres harness installs a real begin/commit/rollback here. */
  public interface Runner { <T> T run(Supplier<T> body); }
  public static Runner RUNNER = new Runner() { public <T> T run(Supplier<T> body) { return body.get(); } };
  public TransactionTemplate(PlatformTransactionManager m) {}
  public void setPropagationBehavior(int b) {}
  public <T> T execute(TransactionCallback<T> action) { return RUNNER.run(() -> action.doInTransaction(null)); }
}
