package org.springframework.web;
public class HttpRequestMethodNotSupportedException extends Exception {}
