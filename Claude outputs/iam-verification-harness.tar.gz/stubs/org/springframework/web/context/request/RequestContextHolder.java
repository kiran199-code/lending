package org.springframework.web.context.request;
public abstract class RequestContextHolder { public static RequestAttributes getRequestAttributes(){return null;} }
