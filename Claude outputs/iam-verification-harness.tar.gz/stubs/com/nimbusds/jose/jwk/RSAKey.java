package com.nimbusds.jose.jwk;
import java.security.interfaces.*;
public final class RSAKey extends JWK {
  public static class Builder { public Builder(RSAPublicKey k){}
    public Builder keyID(String s){return this;} public Builder keyUse(KeyUse u){return this;} public Builder algorithm(com.nimbusds.jose.Algorithm a){return this;}
    public Builder privateKey(RSAPrivateKey k){return this;} public Builder privateKey(java.security.PrivateKey k){return this;} public RSAKey build(){return new RSAKey();} } }
