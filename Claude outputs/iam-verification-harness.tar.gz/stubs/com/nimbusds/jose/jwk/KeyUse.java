package com.nimbusds.jose.jwk;
public enum KeyUse { SIGNATURE }
