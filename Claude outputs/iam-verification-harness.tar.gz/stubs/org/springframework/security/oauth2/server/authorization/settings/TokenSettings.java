package org.springframework.security.oauth2.server.authorization.settings;
import java.time.Duration; import org.springframework.security.oauth2.jose.jws.SignatureAlgorithm;
public final class TokenSettings { public static Builder builder(){return new Builder();} public static final class Builder {
  public Builder accessTokenFormat(OAuth2TokenFormat f){return this;} public Builder accessTokenTimeToLive(Duration d){return this;} public Builder refreshTokenTimeToLive(Duration d){return this;}
  public Builder authorizationCodeTimeToLive(Duration d){return this;} public Builder reuseRefreshTokens(boolean b){return this;} public Builder idTokenSignatureAlgorithm(SignatureAlgorithm a){return this;} public TokenSettings build(){return new TokenSettings();} } }
