package org.springframework.http;
public class ResponseEntity<T> { public final HttpStatus status; public final int code; public final T body;
  ResponseEntity(HttpStatus s,int c,T b){status=s;code=c;body=b;}
  public static Builder status(HttpStatus s){return new Builder(s,0);}
  public static Builder status(int c){return new Builder(null,c);}
  public static <T> ResponseEntity<T> ok(T b){return new ResponseEntity<>(null,200,b);}
  public static Builder notFound(){return new Builder(null,404);}
  public static class Builder { final HttpStatus s; final int c; Builder(HttpStatus s,int c){this.s=s;this.c=c;}
    public <T> ResponseEntity<T> body(T b){return new ResponseEntity<>(s,c,b);}
    public <T> ResponseEntity<T> build(){return new ResponseEntity<>(s,c,null);} } }
