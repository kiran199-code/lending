package org.springframework.jdbc.core;
import java.sql.*;
@FunctionalInterface public interface ResultSetExtractor<T> { T extractData(ResultSet rs) throws SQLException; }
