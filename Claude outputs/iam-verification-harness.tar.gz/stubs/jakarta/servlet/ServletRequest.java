package jakarta.servlet;
public interface ServletRequest { String getRemoteAddr(); String getParameter(String n); Object getAttribute(String n); }
