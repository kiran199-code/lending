package org.springframework.transaction;
public interface TransactionDefinition { int PROPAGATION_REQUIRED=0; int PROPAGATION_NESTED=6; int PROPAGATION_REQUIRES_NEW=3; }
