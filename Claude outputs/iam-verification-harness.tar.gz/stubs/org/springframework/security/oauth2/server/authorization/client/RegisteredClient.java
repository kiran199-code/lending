package org.springframework.security.oauth2.server.authorization.client;
import org.springframework.security.oauth2.core.*; import org.springframework.security.oauth2.server.authorization.settings.*;
public class RegisteredClient { public static Builder withId(String id){return new Builder();} public String getClientId(){return "";}
 public static class Builder { public Builder clientId(String s){return this;} public Builder clientName(String s){return this;} public Builder clientSecret(String s){return this;}
  public Builder clientAuthenticationMethod(ClientAuthenticationMethod m){return this;} public Builder authorizationGrantType(AuthorizationGrantType g){return this;}
  public Builder redirectUri(String s){return this;} public Builder postLogoutRedirectUri(String s){return this;} public Builder scope(String s){return this;}
  public Builder clientSettings(ClientSettings s){return this;} public Builder tokenSettings(TokenSettings s){return this;} public RegisteredClient build(){return new RegisteredClient();} } }
