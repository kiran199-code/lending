package org.springframework.security.oauth2.server.authorization.settings;
public final class ClientSettings { public static Builder builder(){return new Builder();} public static final class Builder { public Builder requireProofKey(boolean b){return this;} public Builder requireAuthorizationConsent(boolean b){return this;} public ClientSettings build(){return new ClientSettings();} } }
