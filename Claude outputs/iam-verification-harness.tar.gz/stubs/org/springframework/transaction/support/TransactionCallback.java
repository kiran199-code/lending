package org.springframework.transaction.support;
import org.springframework.transaction.TransactionStatus;
@FunctionalInterface public interface TransactionCallback<T> { T doInTransaction(TransactionStatus status); }
