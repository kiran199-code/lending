package org.springframework.security.oauth2.jwt;
public class JwtClaimsSet { public static class Builder { public Builder claim(String n, Object v){return this;} } }
