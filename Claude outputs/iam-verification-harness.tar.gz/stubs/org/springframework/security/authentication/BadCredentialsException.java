package org.springframework.security.authentication;
public class BadCredentialsException extends org.springframework.security.core.AuthenticationException { public BadCredentialsException(String m){super(m);} }
