IAM verification harness (scaffolding, not product code)
Layout expected: <root>/{build_check.sh,runmig.sh,stubs/,harness/,lending-iam-service/}
Hard-coded: /home/claude/iamsvc, /opt/gradle-8.14.3/lib (jackson, slf4j jars), `su postgres -c psql`, python3 + psycopg2.
Run: ./build_check.sh ; (cd harness && ./run.sh)   -> "563 checks, 0 failures"
See lending-iam-service/VERIFICATION.md for what this does and does not prove.
