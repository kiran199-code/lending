package com.nimbusds.jose.jwk;
public abstract class JWK {}
