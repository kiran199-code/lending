package org.springframework.security.oauth2.server.authorization.token;
public interface OAuth2TokenCustomizer<C> { void customize(C context); }
