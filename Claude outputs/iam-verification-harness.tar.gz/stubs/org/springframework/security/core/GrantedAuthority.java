package org.springframework.security.core;
public interface GrantedAuthority extends java.io.Serializable { String getAuthority(); }
