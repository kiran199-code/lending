"""Run from the repository root:  python patch_root_files.py
Adds the LCM settings to the admin service in render.yaml and a CHANGELOG entry. Idempotent; commits nothing."""
import re, sys, pathlib

root = pathlib.Path('.')
ry = root / 'render.yaml'
text = ry.read_text(encoding='utf-8')
if 'LCM_SERVICE_URL' in text:
    print('render.yaml: already has LCM_SERVICE_URL, left alone')
else:
    lines = text.split('\n')
    start = next((i for i, l in enumerate(lines) if re.search(r'name:\s*lending-admin-service\s*$', l)), None)
    if start is None:
        sys.exit('render.yaml: no lending-admin-service block found; add the three variables by hand')
    env = next((i for i in range(start, len(lines)) if lines[i].strip() == 'envVars:'), None)
    if env is None:
        sys.exit('render.yaml: admin service has no envVars block')
    ind = re.match(r'\s*', lines[env + 1]).group(0)
    add = [
        f'{ind}- key: LCM_SERVICE_URL',
        f'{ind}  sync: false             # https://lending-lcm-service-XXXX.onrender.com (enables the Limits & collateral screens)',
        f'{ind}- key: LCM_SERVICE_USERNAME',
        f'{ind}  value: lcm-service',
        f'{ind}- key: LCM_SERVICE_PASSWORD',
        f'{ind}  fromService: {{ type: web, name: lending-lcm-service, envVarKey: LCM_SERVICE_PASSWORD }}',
    ]
    lines[env + 1:env + 1] = add
    ry.write_text('\n'.join(lines), encoding='utf-8')
    print('render.yaml: added LCM_SERVICE_URL / USERNAME / PASSWORD to lending-admin-service')

cl = root / 'CHANGELOG.md'
entry = ("- **Admin console: limit and collateral screens, and the facility on loan screens.** New menu section *Limits & collateral* "
         "(facilities, approvals, collateral, monitoring) in front of lending-lcm-service; *Create loan* offers the customer's active facilities, "
         "*Accounts* has a Limit facility column, *Account detail* shows the facility and can attach, change or clear it while the loan is pending disbursement "
         "(`PUT /api/v1/loan-accounts/{id}/limit-facility`). LCM now refuses a loan whose customer differs from the facility's (`CUSTOMER_MISMATCH`) and has "
         "list endpoints for pending changes, excess and valuations. The *Acting as* name on the limit screens is typed, not verified. "
         "Deploy order: LCM, lending-service, admin. New admin settings: `LCM_SERVICE_URL`, `LCM_SERVICE_USERNAME`, `LCM_SERVICE_PASSWORD`.")
if cl.exists():
    t = cl.read_text(encoding='utf-8')
    if 'limit and collateral screens' in t:
        print('CHANGELOG.md: entry already present')
    else:
        m = re.search(r'## \[Unreleased\][\s\S]*?### Added\s*\n', t)
        if m:
            t = t[:m.end()] + entry + '\n' + t[m.end():]
            cl.write_text(t, encoding='utf-8')
            print('CHANGELOG.md: entry added under Unreleased / Added')
        else:
            print('CHANGELOG.md: no Unreleased / Added heading found; add this by hand:\n' + entry)
