package jakarta.servlet.http;
public interface HttpServletRequest extends jakarta.servlet.ServletRequest { String getHeader(String n); String getRequestURI(); String getMethod(); String getContextPath(); HttpSession getSession(); HttpSession getSession(boolean create); }
