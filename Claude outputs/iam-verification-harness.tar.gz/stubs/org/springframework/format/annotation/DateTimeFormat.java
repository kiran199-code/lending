package org.springframework.format.annotation;
import java.lang.annotation.*;
@Retention(RetentionPolicy.RUNTIME) public @interface DateTimeFormat { ISO iso() default ISO.NONE; enum ISO { NONE, DATE, TIME, DATE_TIME } }
