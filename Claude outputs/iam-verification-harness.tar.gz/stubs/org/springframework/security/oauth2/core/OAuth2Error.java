package org.springframework.security.oauth2.core;
public class OAuth2Error { public OAuth2Error(String code, String description, String uri){} }
