package org.springframework.transaction.annotation;
import java.lang.annotation.*;
@Retention(RetentionPolicy.RUNTIME) public @interface Transactional { Propagation propagation() default Propagation.REQUIRED; boolean readOnly() default false; Class<? extends Throwable>[] noRollbackFor() default {}; }
