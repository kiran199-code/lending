package org.springframework.security.crypto.bcrypt;
public class BCryptPasswordEncoder implements org.springframework.security.crypto.password.PasswordEncoder {
  public BCryptPasswordEncoder(int strength){} public String encode(CharSequence r){return "$2a$11$x";} public boolean matches(CharSequence r,String e){return false;} }
