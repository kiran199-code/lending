package org.springframework.security.oauth2.jwt;
import java.util.Map;
public class Jwt {
    private final Map<String,Object> claims;
    public Jwt(Map<String,Object> claims) { this.claims = claims; }
    public Map<String,Object> getClaims() { return claims; }
}
