package org.springframework.security.core.context;
public interface SecurityContext extends java.io.Serializable {}
