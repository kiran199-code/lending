package org.springframework.web.servlet.resource;
public class NoResourceFoundException extends Exception {}
