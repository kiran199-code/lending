package org.springframework.security.oauth2.core;
public interface OAuth2ErrorCodes { String INVALID_GRANT = "invalid_grant"; }
