package org.assertj.core.api;

import java.math.BigDecimal;
import java.util.Arrays;
import java.util.Collection;
import java.util.Objects;

/** Minimal local stand-in for the AssertJ subset used by the accounting tests (real AssertJ runs in the build). */
public class Assertions {
    public static Subject assertThat(Object o) { return new Subject(o); }
    public static Subject assertThat(boolean o) { return new Subject(o); }
    public static Subject assertThat(int o) { return new Subject(o); }
    public static Subject assertThat(long o) { return new Subject(o); }
    public static ThrownSubject assertThatThrownBy(ThrowingCallable c) {
        try { c.call(); } catch (Throwable t) { return new ThrownSubject(t); }
        throw new AssertionError("Expected an exception but none was thrown");
    }
    public interface ThrowingCallable { void call() throws Throwable; }

    public static class ThrownSubject {
        final Throwable t;
        ThrownSubject(Throwable t) { this.t = t; }
        public ThrownSubject isInstanceOf(Class<?> c) {
            if (!c.isInstance(t)) throw new AssertionError("Expected " + c.getName() + " but was " + t);
            return this;
        }
        public ThrownSubject hasMessageContaining(String s) {
            if (t.getMessage() == null || !t.getMessage().contains(s)) throw new AssertionError("Message '" + t.getMessage() + "' lacks '" + s + "'");
            return this;
        }
        public ThrownSubject isSameAs(Object o) { if (t != o) throw new AssertionError("Expected the same exception but was " + t); return this; }
        public Throwable get() { return t; }
    }

    public static class Subject {
        final Object a;
        Subject(Object a) { this.a = a; }
        private static void fail(String m) { throw new AssertionError(m); }
        public Subject isEqualTo(Object e) { if (!Objects.equals(a, e)) fail("expected <" + e + "> but was <" + a + ">"); return this; }
        public Subject isNotEqualTo(Object e) { if (Objects.equals(a, e)) fail("expected not <" + e + ">"); return this; }
        public Subject isEqualByComparingTo(BigDecimal e) { if (((BigDecimal) a).compareTo(e) != 0) fail("expected <" + e + "> but was <" + a + ">"); return this; }
        public Subject isEqualByComparingTo(String e) { return isEqualByComparingTo(new BigDecimal(e)); }
        public Subject isNull() { if (a != null) fail("expected null but was " + a); return this; }
        public Subject isNotNull() { if (a == null) fail("expected not null"); return this; }
        public Subject isTrue() { if (!Boolean.TRUE.equals(a)) fail("expected true but was " + a); return this; }
        public Subject isFalse() { if (!Boolean.FALSE.equals(a)) fail("expected false but was " + a); return this; }
        public Subject isZero() { if (a instanceof BigDecimal b ? b.signum() != 0 : ((Number) a).doubleValue() != 0) fail("expected zero but was " + a); return this; }
        public Subject isEmpty() { if (!((Collection<?>) a).isEmpty()) fail("expected empty but was " + a); return this; }
        public Subject isNotEmpty() { if (((Collection<?>) a).isEmpty()) fail("expected not empty"); return this; }
        public Subject hasSize(int n) { if (((Collection<?>) a).size() != n) fail("expected size " + n + " but was " + ((Collection<?>) a).size() + ": " + a); return this; }
        public Subject isGreaterThan(long n) { if (((Number) a).longValue() <= n) fail("expected > " + n + " but was " + a); return this; }
        public Subject isInstanceOf(Class<?> c) { if (!c.isInstance(a)) fail("expected " + c.getName() + " but was " + a); return this; }
        public Subject contains(Object... xs) { if (a instanceof CharSequence cs) { for (Object x : xs) if (!cs.toString().contains(String.valueOf(x))) fail("expected <" + a + "> to contain <" + x + ">"); return this; } Collection<?> c = (Collection<?>) a; for (Object x : xs) if (!c.contains(x)) fail("expected " + a + " to contain " + x); return this; }
        public Subject containsExactly(Object... xs) { if (!Arrays.asList(xs).equals(new java.util.ArrayList<>((Collection<?>) a))) fail("expected exactly " + Arrays.asList(xs) + " but was " + a); return this; }
    }
}
