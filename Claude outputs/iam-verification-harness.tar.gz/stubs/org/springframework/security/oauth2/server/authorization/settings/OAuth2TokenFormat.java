package org.springframework.security.oauth2.server.authorization.settings;
public final class OAuth2TokenFormat { public static final OAuth2TokenFormat SELF_CONTAINED = new OAuth2TokenFormat(); }
