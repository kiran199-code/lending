package org.springframework.security.oauth2.server.authorization.token;
import org.springframework.security.oauth2.jwt.*; import org.springframework.security.oauth2.server.authorization.*; import org.springframework.security.oauth2.server.authorization.client.*; import org.springframework.security.oauth2.core.*; import org.springframework.security.core.Authentication;
public final class JwtEncodingContext { public JwsHeader.Builder getJwsHeader(){return null;} public JwtClaimsSet.Builder getClaims(){return null;} public OAuth2TokenType getTokenType(){return null;}
  public AuthorizationGrantType getAuthorizationGrantType(){return null;} public RegisteredClient getRegisteredClient(){return null;} public <T extends Authentication> T getPrincipal(){return null;} }
