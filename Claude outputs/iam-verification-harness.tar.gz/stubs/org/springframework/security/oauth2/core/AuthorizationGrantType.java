package org.springframework.security.oauth2.core;
public final class AuthorizationGrantType { public static final AuthorizationGrantType CLIENT_CREDENTIALS = new AuthorizationGrantType("client_credentials"); public AuthorizationGrantType(String v){} }
