package org.springframework.security.web.authentication;
import jakarta.servlet.http.*; import org.springframework.security.core.Authentication;
public class SavedRequestAwareAuthenticationSuccessHandler { public void setDefaultTargetUrl(String u){}
  public void onAuthenticationSuccess(HttpServletRequest rq, HttpServletResponse rs, Authentication a) throws java.io.IOException, jakarta.servlet.ServletException {} }
