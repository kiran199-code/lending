package jakarta.servlet;
public interface FilterChain { void doFilter(ServletRequest rq, ServletResponse rs) throws java.io.IOException, ServletException; }
