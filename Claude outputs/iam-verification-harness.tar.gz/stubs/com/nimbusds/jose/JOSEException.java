package com.nimbusds.jose;
public class JOSEException extends Exception { }
