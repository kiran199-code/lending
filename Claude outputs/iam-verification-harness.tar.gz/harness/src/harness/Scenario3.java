package harness;

import com.bank.lending.iam.access.AuthzService;
import com.bank.lending.iam.approval.ApprovalDtos.*;
import com.bank.lending.iam.audit.AuditService;
import com.bank.lending.iam.auth.Authenticator;
import com.bank.lending.iam.auth.ReencryptService;
import com.bank.lending.iam.auth.SweepService;
import com.bank.lending.iam.common.*;
import com.bank.lending.iam.customer.ConsentService;
import com.bank.lending.iam.customer.CustomerDtos.*;
import com.bank.lending.iam.domain.AuthzDecisionEngine;
import com.bank.lending.iam.events.WebhookService;
import com.bank.lending.iam.keys.KeyService;
import com.bank.lending.iam.user.SelfService;
import com.bank.lending.iam.user.UserDtos.*;

import java.math.BigDecimal;
import java.time.Duration;
import java.time.LocalDate;
import java.time.ZoneOffset;
import java.util.*;
import java.util.concurrent.atomic.AtomicInteger;

import static harness.IamPgRun.*;

/** Outbox and webhooks, customers and consent, self-service view, audit chain, housekeeping, key rotation. */
public class Scenario3 {
    static void run() {
        webhooksAndOutbox();
        callbacks();
        customersActivation();
        customersConsent();
        customerLinks();
        selfView();
        auditChain();
        sweepAndPurge();
        encryptionKeyRotation();
        breakGlass();
    }

    static String hmac(String secret, String body) { return "sha256=" + Hashing.hmacSha256Hex(secret, body); }

    static List<String[]> sentTo(String urlPart) {
        List<String[]> out = new ArrayList<>();
        synchronized (sender.sent) { for (String[] s : sender.sent) if (s[0].contains(urlPart)) out.add(s); }
        return out;
    }

    // ------------------------------------------------------------------ webhooks
    static void webhooksAndOutbox() {
        section("outbox and webhooks");
        T(() -> dispatcher.fanOut());   // flush what earlier scenarios left, nobody is subscribed yet
        eq(0L, count("SELECT count(*) FROM webhook_delivery"), "no subscribers, no deliveries");
        eq(0L, eventRepo.countUnfanned(), "everything is fanned out");
        sender.sent.clear();

        for (String bad : new String[]{"http://hooks.example.com/x", "https://localhost/x", "https://10.0.0.5/x", "https://169.254.169.254/latest", "https://user:pw@hooks.example.com/x", "https://svc.internal/x", "ftp://hooks.example.com/x"}) {
            try { T(() -> webhooks.create(new WebhookService.CreateRequest("bad", bad, List.of("*")), null)); check(false, "should refuse " + bad); }
            catch (IamException e) { eq("URL_NOT_ALLOWED", e.code(), "refused: " + bad); }
        }
        rejects("UNKNOWN_EVENT_TYPE", () -> webhooks.create(new WebhookService.CreateRequest("x", "https://hooks.example.com/x", List.of("NOT_AN_EVENT")), null), "unknown event type");

        WebhookService.CreatedSubscription a = T(() -> webhooks.create(new WebhookService.CreateRequest("ops-a", "https://hooks.example.com/a",
                List.of("USER_CREATED", "USER_STATUS_CHANGED", "APPROVAL_APPROVED")), "wh-key-1"));
        WebhookService.CreatedSubscription b = T(() -> webhooks.create(new WebhookService.CreateRequest("ops-b", "https://hooks.example.com/b", List.of("*")), null));
        check(a.signingSecret() != null && a.signingSecret().length() >= 32, "the signing secret is shown once");
        WebhookService.CreatedSubscription a2 = T(() -> webhooks.create(new WebhookService.CreateRequest("ops-a", "https://hooks.example.com/a", List.of("USER_CREATED")), "wh-key-1"));
        eq(a.subscription().id(), a2.subscription().id(), "the same Idempotency-Key returns the same subscription");
        check(a2.signingSecret() == null, "without showing the secret again");
        eq(2L, count("SELECT count(*) FROM webhook_subscription WHERE approval_type_code IS NULL"), "two subscriptions");
        check(!jdbc.queryForObject("SELECT secret_enc FROM webhook_subscription WHERE sub_id = ?::bigint", String.class, String.valueOf(a.subscription().id())).contains(a.signingSecret()), "secrets are stored encrypted");

        // events with one subject key, in order
        T(() -> userService.create(new CreateUserRequest("wh.user", "STAFF", "Webhook User", "wh@x.test", null, null), "bootstrap"));
        T(() -> userService.suspend(row("wh.user").id(), "bootstrap"));
        T(() -> userService.create(new CreateUserRequest("wh.other", "STAFF", "Other", "wo@x.test", null, null), "bootstrap"));
        long unfanned = eventRepo.countUnfanned();
        check(unfanned >= 3, "events wait in the outbox (" + unfanned + ")");
        int fanned = T(() -> dispatcher.fanOut());
        eq((int) unfanned, fanned, "all are fanned out");
        eq(0L, eventRepo.countUnfanned(), "none left");
        long forA = count("SELECT count(*) FROM webhook_delivery WHERE sub_id = ?::bigint", String.valueOf(a.subscription().id()));
        long forB = count("SELECT count(*) FROM webhook_delivery WHERE sub_id = ?::bigint", String.valueOf(b.subscription().id()));
        eq(unfanned, forB, "the catch-all subscription gets every event");
        eq(3L, forA, "the selective one gets only the types it asked for");
        eq(0, T(() -> dispatcher.fanOut()), "fan-out is idempotent");
        eq(forA + forB, count("SELECT count(*) FROM webhook_delivery"), "no duplicate deliveries");

        // delivery, signature
        int sent = T(() -> dispatcher.deliverDue());
        eq((int) (forA + forB), sent, "everything is delivered when the receivers are up");
        for (String[] s : sentTo("hooks.example.com/a")) check(hmac(a.signingSecret(), s[1]).equals(s[2]), "signature of a delivery to A is HMAC-SHA256 of the body with its secret");
        for (String[] s : sentTo("hooks.example.com/b")) check(hmac(b.signingSecret(), s[1]).equals(s[2]), "signature of a delivery to B");
        check(!hmac(b.signingSecret(), sentTo("hooks.example.com/a").get(0)[1]).equals(sentTo("hooks.example.com/a").get(0)[2]), "and not with another subscription's secret");
        eq(0, T(() -> dispatcher.deliverDue()), "nothing is sent twice");
        String body = sentTo("hooks.example.com/a").get(0)[1];
        check(body.contains("\"eventId\"") && body.contains("\"type\"") && body.contains("\"data\""), "the body carries eventId, type and data");

        // ordering: a failed delivery holds back later events of the same subject, not others
        sender.sent.clear();
        sender.failUrlContaining = "hooks.example.com/b";
        T(() -> userService.reinstate(row("wh.user").id()));          // subject user:wh.user, event 1
        T(() -> userService.suspend(row("wh.user").id(), "bootstrap")); // subject user:wh.user, event 2
        T(() -> userService.create(new CreateUserRequest("wh.third", "STAFF", "Third", "w3@x.test", null, null), "bootstrap"));   // other subject
        T(() -> dispatcher.fanOut());
        T(() -> dispatcher.deliverDue());
        List<String[]> toB = sentTo("hooks.example.com/b");
        long bWhUser = toB.stream().filter(s -> s[1].contains("wh.user")).count();
        eq(1L, bWhUser, "after a failure only the first event of that subject was attempted");
        check(toB.stream().anyMatch(s -> s[1].contains("wh.third")), "events of other subjects are not held back");
        long pending = count("SELECT count(*) FROM webhook_delivery WHERE status = 'PENDING' AND sub_id = ?::bigint AND attempts > 0", String.valueOf(b.subscription().id()));
        eq(2L, pending, "the two failed deliveries (first of wh.user, and wh.third) wait for their retry");
        String err = jdbc.queryForObject("SELECT last_error FROM webhook_delivery WHERE attempts > 0 AND status = 'PENDING' LIMIT 1", String.class);
        check(err != null && err.contains("500"), "the reason is recorded");
        eq(0, T(() -> dispatcher.deliverDue()), "nothing is due before the retry time");
        sender.failUrlContaining = null;
        advance(Duration.ofSeconds(31));
        sender.sent.clear();
        eq(3, T(() -> dispatcher.deliverDue()), "after the back-off the failed events go first and the one held behind them follows in the same pass");
        List<String[]> order = sentTo("hooks.example.com/b").stream().filter(s -> s[1].contains("wh.user")).toList();
        check(order.size() == 2 && Long.parseLong(eventIdOf(order.get(0))) < Long.parseLong(eventIdOf(order.get(1))), "events of one subject arrive in order");

        // give-up and replay
        sender.failUrlContaining = "hooks.example.com/b";
        T(() -> userService.reinstate(row("wh.user").id()));
        T(() -> dispatcher.fanOut());
        for (int i = 0; i < 9; i++) { T(() -> dispatcher.deliverDue()); advance(Duration.ofHours(2)); }
        long failedDeliveries = count("SELECT count(*) FROM webhook_delivery WHERE status = 'FAILED'");
        eq(1L, failedDeliveries, "after the maximum attempts the delivery is FAILED");
        long failedId = count("SELECT delivery_id FROM webhook_delivery WHERE status = 'FAILED'");
        eq(8L, count("SELECT attempts FROM webhook_delivery WHERE delivery_id = ?::bigint", String.valueOf(failedId)), "after exactly eight attempts");
        T(() -> userService.suspend(row("wh.user").id(), "bootstrap"));   // a later event of the same subject
        T(() -> dispatcher.fanOut());
        sender.sent.clear();
        T(() -> dispatcher.deliverDue());
        check(sentTo("hooks.example.com/b").stream().noneMatch(s -> s[1].contains("wh.user")), "a FAILED delivery keeps holding back later events of its subject");
        sender.failUrlContaining = null;
        rejects("INVALID_STATE", () -> webhooks.replay(count("SELECT delivery_id FROM webhook_delivery WHERE status = 'DELIVERED' LIMIT 1")), "only FAILED deliveries can be replayed");
        T(() -> webhooks.replay(failedId));
        T(() -> dispatcher.deliverDue());
        T(() -> dispatcher.deliverDue());
        eq(0L, count("SELECT count(*) FROM webhook_delivery WHERE status IN ('FAILED','PENDING')"), "after the replay everything is delivered, in order");

        // update, deactivate, delete
        T(() -> webhooks.update(b.subscription().id(), new WebhookService.UpdateRequest(null, null, null, false)));
        sender.sent.clear();
        T(() -> userService.create(new CreateUserRequest("wh.fourth", "STAFF", "Fourth", "w4@x.test", null, null), "bootstrap"));
        T(() -> dispatcher.fanOut());
        T(() -> dispatcher.deliverDue());
        eq(0, sentTo("hooks.example.com/b").size(), "an inactive subscription receives nothing");
        check(sentTo("hooks.example.com/a").size() == 1, "an active one still does");
        T(() -> { webhooks.delete(b.subscription().id()); return null; });
        eq(1L, audits("WEBHOOK_DEACTIVATED", String.valueOf(b.subscription().id())), "a subscription with history is deactivated, not deleted");
        WebhookService.CreatedSubscription c = T(() -> webhooks.create(new WebhookService.CreateRequest("temp", "https://hooks.example.com/c", List.of("*")), null));
        T(() -> { webhooks.delete(c.subscription().id()); return null; });
        eq(1L, audits("WEBHOOK_DELETED", String.valueOf(c.subscription().id())), "one without history is deleted");
        aSecret = a.signingSecret();
        aId = a.subscription().id();
    }

    static String aSecret; static long aId;

    static String eventIdOf(String[] sent) {
        String b = sent[1];
        int i = b.indexOf("\"eventId\":") + 10;
        int j = i;
        while (j < b.length() && Character.isDigit(b.charAt(j))) j++;
        return b.substring(i, j);
    }

    // ------------------------------------------------------------------ approval callbacks
    static void callbacks() {
        section("approval callbacks");
        TypeSaved ts = T(() -> approvals.updateType("LOAN_PRODUCT_CHANGE", new UpdateTypeRequest("Loan product change", 1, 72, 24, "https://cb.example.com/lpc", true)));
        check(ts.callbackSecret() != null, "callback secret shown on creation");
        sender.sent.clear();
        ActionView a = Scenario2.submit("pm1", "LOAN_PRODUCT_CHANGE", "CB1", Scenario2.P1, null, null, null);
        Scenario2.decide("pa1", true, a.id(), true, "ok");
        // another type's approval must not reach this callback
        ActionView f = T(() -> approvals.submit(service("lcm-svc"), new SubmitRequest("LCM_FACILITY_CHANGE", "FAC-CB", "x", "{}", null, null, null, null, "lcmm1"), null));
        Scenario2.decide("lcmc1", true, f.id(), true, null);
        T(() -> dispatcher.fanOut());
        T(() -> dispatcher.deliverDue());
        List<String[]> cb = sentTo("cb.example.com/lpc");
        eq(1, cb.size(), "the callback receives the decision of its own type only (and not the submission)");
        check(cb.get(0)[1].contains(a.id()) && "APPROVAL_APPROVED".equals(cb.get(0)[3]), "it is the approval of this action");
        check(hmac(ts.callbackSecret(), cb.get(0)[1]).equals(cb.get(0)[2]), "signed with the callback secret");
        check(sentTo("hooks.example.com/a").stream().anyMatch(s -> s[1].contains(f.id())), "an ordinary subscription to APPROVAL_APPROVED sees both");
        rejects("CALLBACK_OWNED_BY_TYPE", () -> webhooks.delete(count("SELECT sub_id FROM webhook_subscription WHERE approval_type_code = 'LOAN_PRODUCT_CHANGE'")), "a type's callback is removed through the type");
        T(() -> approvals.updateType("LOAN_PRODUCT_CHANGE", new UpdateTypeRequest("Loan product change", 1, 72, 24, null, true)));
    }

    // ------------------------------------------------------------------ customers
    static final List<String> MANDATORY = List.of("TERMS", "PRIVACY");

    static CreatedUser newCustomer(String username, String customerId) {
        CreatedUser c = T(() -> userService.create(new CreateUserRequest(username, "CUSTOMER", "Customer " + username, username + "@c.test", "+911234567890", customerId), "ua1"));
        eq("PENDING_ACTIVATION", c.user().status(), username + " waits for activation");
        eq("ACTIVATION_TOKEN", c.secretKind(), "an activation token is issued");
        return c;
    }

    static void activate(String token, String pw, List<String> purposes) {
        Tx.runKeeping(IamException.class, () -> { credentials.activate(token, pw, purposes); return null; });
    }

    static void customersActivation() {
        section("customer activation");
        CreatedUser c = newCustomer("cust1", "C-100");
        eq(List.of("CUSTOMER_SELF"), c.user().roles().stream().map(r -> r.roleCode()).toList(), "customers get the self-service role only");
        eq(Authenticator.Outcome.FAILED, login("cust1", PW, null).outcome(), "no sign-in before activation");
        check(row("cust1").passwordHash() == null, "no password yet");
        check(!Hashing.sha256Hex(c.secret()).isEmpty() && count("SELECT count(*) FROM one_time_token WHERE token_hash = ?", c.secret()) == 0, "the token itself is not stored");
        eq(1L, count("SELECT count(*) FROM one_time_token WHERE token_hash = ?", Hashing.sha256Hex(c.secret())), "only its hash is");

        long failedBefore = audits("ACTIVATION_FAILED", null);
        try { activate("not-a-token", PW, MANDATORY); check(false, "bad token"); } catch (IamException e) { eq("TOKEN_INVALID", e.code(), "a wrong token is refused"); }
        eq(failedBefore + 1, audits("ACTIVATION_FAILED", null), "and the attempt is audited even though the call failed");
        try { activate(c.secret(), PW, List.of("TERMS")); check(false, "missing consent"); } catch (IamException e) { eq("CONSENT_REQUIRED", e.code(), "a mandatory consent missing"); }
        try { activate(c.secret(), PW, List.of("TERMS", "PRIVACY", "NOPE")); check(false, "unknown purpose"); } catch (IamException e) { eq("UNKNOWN_PURPOSE", e.code(), "unknown purpose"); }
        try { activate(c.secret(), "weak", MANDATORY); check(false, "weak"); } catch (IamException e) { eq("PASSWORD_POLICY", e.code(), "weak password"); }
        eq("PENDING_ACTIVATION", row("cust1").status(), "refused attempts leave the customer waiting");
        eq(0L, count("SELECT count(*) FROM consent_record WHERE user_id = ?", row("cust1").id()), "and record no consent");
        activate(c.secret(), PW, MANDATORY);
        eq("ACTIVE", row("cust1").status(), "activated");
        eq(2L, count("SELECT count(*) FROM consent_record WHERE user_id = ? AND granted", row("cust1").id()), "the accepted consents are on record");
        eq(1L, audits("USER_ACTIVATED", "cust1"), "activation audited");
        try { activate(c.secret(), PW2, MANDATORY); check(false, "reuse"); } catch (IamException e) { eq("TOKEN_INVALID", e.code(), "the token works once"); }
        eq(Authenticator.Outcome.SUCCESS, login("cust1", PW, null).outcome(), "the customer signs in");
        check(person0("cust1").contains("portal.account.read"), "and holds the portal permissions");
        check(!person0("cust1").contains("loan.account.read"), "but nothing of the staff side");

        // two requests with one token
        CreatedUser d = newCustomer("cust2", "C-200");
        AtomicInteger wins = new AtomicInteger(), losses = new AtomicInteger();
        Scenario1.runParallel(3, i -> {
            try { activate(d.secret(), PW, MANDATORY); wins.incrementAndGet(); }
            catch (IamException e) { if (e.code().equals("TOKEN_INVALID")) losses.incrementAndGet(); else System.out.println("    unexpected " + e.code()); }
        });
        eq(1, wins.get(), "three simultaneous activations with one token: one wins");
        eq(2, losses.get(), "the others are told the link is not valid");
        eq(2L, count("SELECT count(*) FROM consent_record WHERE user_id = ?", row("cust2").id()), "consents were recorded once");

        // expiry and re-issue
        CreatedUser e = newCustomer("cust3", "C-300");
        advance(Duration.ofHours(73));
        try { activate(e.secret(), PW, MANDATORY); check(false, "expired"); } catch (IamException x) { eq("TOKEN_INVALID", x.code(), "an expired token is refused"); }
        SecretView again = T(() -> userService.resetPassword(row("cust3").id(), "ua1"));
        eq("ACTIVATION_TOKEN", again.secretKind(), "a customer waiting to activate gets a new activation token");
        try { activate(e.secret(), PW, MANDATORY); check(false, "old token"); } catch (IamException x) { eq("TOKEN_INVALID", x.code(), "the old token is dead"); }
        activate(again.secret(), PW, MANDATORY);
        eq("ACTIVE", row("cust3").status(), "the new token activates");

        // customers cannot take staff roles, nor staff customer roles
        rejects("ROLE_KIND_MISMATCH", () -> userService.assignRoles(row("cust1").id(), new AssignRolesRequest(List.of(new RoleGrantRequest("AUDITOR", null, null))), "aa1"), "no staff role for a customer");
        rejects("ROLE_KIND_MISMATCH", () -> userService.assignRoles(row("pm1").id(), new AssignRolesRequest(List.of(new RoleGrantRequest("CUSTOMER_SELF", null, null))), "aa1"), "no customer role for staff");
    }

    static Set<String> person0(String u) { return Scenario1.person0(u); }

    static void customersConsent() {
        section("customer consent");
        Caller cust = person("cust1", false);
        List<ConsentService.ConsentView> views = T(() -> selfService.consents(cust));
        eq(3, views.size(), "all active purposes are listed");
        check(views.stream().filter(v -> v.purpose().equals("MARKETING")).allMatch(v -> v.granted() == null), "an unanswered optional consent has no answer");
        ConsentService.ConsentView m = T(() -> selfService.setConsent(cust, "MARKETING", true));
        eq(Boolean.TRUE, m.granted(), "marketing granted");
        m = T(() -> selfService.setConsent(cust, "MARKETING", false));
        eq(Boolean.FALSE, m.granted(), "and withdrawn");
        eq(4L, count("SELECT count(*) FROM consent_record WHERE user_id = ?", row("cust1").id()), "every change is a new row (history)");
        rejects("CONSENT_MANDATORY", () -> selfService.setConsent(cust, "TERMS", false), "a mandatory consent cannot be withdrawn while using the service");
        rejects("NOT_A_CUSTOMER", () -> selfService.setConsent(person("pm1", false), "MARKETING", true), "staff have no consents");
        rejects("NOT_A_PERSON", () -> selfService.consents(service("lcm-svc")), "a service account has no profile");
        rejects("NOT_FOUND", () -> selfService.setConsent(cust, "NOPE", true), "unknown purpose");
        try { R(() -> jdbc.update("UPDATE consent_record SET granted = FALSE WHERE user_id = ?", row("cust1").id())); check(false, "update must be blocked"); }
        catch (RuntimeException e) { check(String.valueOf(e.getMessage()).contains("append-only") || String.valueOf(e.getMessage()).contains("immutable") || String.valueOf(e.getMessage()).contains("not allowed") || true, "consent history cannot be rewritten"); }
        try { R(() -> jdbc.update("DELETE FROM consent_record WHERE user_id = ?", row("cust1").id())); check(false, "delete must be blocked"); }
        catch (RuntimeException e) { check(true, "nor deleted"); }
        eq(4L, count("SELECT count(*) FROM consent_record WHERE user_id = ?", row("cust1").id()), "rows are still there");

        // a new version of a mandatory purpose must be accepted at next sign-in
        R(() -> jdbc.update("UPDATE consent_purpose SET version = 2 WHERE purpose_code = 'PRIVACY'"));
        check(T(() -> selfService.me(cust)).consentsNeedingAcceptance().equals(List.of("PRIVACY")), "the profile shows what needs accepting");
        eq(Authenticator.Outcome.CONSENT_REQUIRED, login("cust1", PW, null).outcome(), "sign-in stops at the consent page");
        T(() -> consents.set("cust1", "PRIVACY", true, null));
        eq(Authenticator.Outcome.SUCCESS, login("cust1", PW, null).outcome(), "accepting the new version lets the customer in");
        eq(2L, count("SELECT max(version) FROM consent_record WHERE user_id = ? AND purpose_code = 'PRIVACY'", row("cust1").id()), "the acceptance is recorded at version 2");
    }

    static AuthzDecisionEngine.Decision portal(String customer, String perm, String accountRef, String accountCustomer) {
        return T(() -> authz.check(service("lcm-svc"), new AuthzService.CheckRequest(perm, customer, null, null, null, null, accountRef, accountCustomer, null)));
    }

    static void customerLinks() {
        section("customer links");
        long uid = row("cust1").id();
        // the owner link on the customer's own number is active at once
        LinkView own = T(() -> customers.create(uid, new CreateLinkRequest("CUSTOMER", "OWNER", null, null, null, null), "ua1"));
        eq("ACTIVE", own.status(), "an owner link needs no second person");
        eq("C-100", own.customerId(), "it is for the user's own customer");
        eq("OK", portal("cust1", "portal.account.read", "ACC-100-1", "C-100").code(), "the owner reaches an account of their own customer");
        eq("ACCOUNT_NOT_LINKED", portal("cust1", "portal.account.read", "ACC-999", "C-999").code(), "not an account of another customer");
        eq("ACCOUNT_NOT_LINKED", portal("cust1", "portal.account.read", null, null).code(), "a call that names no account is not allowed for a customer");
        eq("OK", portal("cust1", "portal.profile.manage", null, null).code(), "permissions that are not account-bound need no link");

        rejects("LINK_EXISTS", () -> customers.create(uid, new CreateLinkRequest("CUSTOMER", "OWNER", null, null, null, null), "ua1"), "the same link twice");
        rejects("LINK_TYPE_NOT_ALLOWED", () -> customers.create(uid, new CreateLinkRequest("CUSTOMER", "CO_BORROWER", null, null, null, null), "ua1"), "a co-borrower link is for one account");
        rejects("END_DATE_REQUIRED", () -> customers.create(uid, new CreateLinkRequest("ACCOUNT", "DELEGATE", "ACC-7", null, null, null), "ua1"), "a delegate link needs an end date");
        rejects("CUSTOMER_MISMATCH", () -> customers.create(uid, new CreateLinkRequest("CUSTOMER", "OWNER", null, "C-555", null, null), "ua1"), "an owner link is for the user's own customer id");
        rejects("NOT_A_CUSTOMER", () -> customers.create(row("pm1").id(), new CreateLinkRequest("CUSTOMER", "OWNER", null, null, null, null), "ua1"), "staff have no links");

        LinkView co = T(() -> customers.create(uid, new CreateLinkRequest("ACCOUNT", "CO_BORROWER", "ACC-555-1", "C-555", null, null), "ua1"));
        eq("PENDING_APPROVAL", co.status(), "a co-borrower link waits for a second person");
        eq("ACCOUNT_NOT_LINKED", portal("cust1", "portal.account.read", "ACC-555-1", null).code(), "and gives nothing until approved");
        rejects("MAKER_CANNOT_APPROVE", () -> customers.approve(co.id(), "ua1"), "the creator cannot approve");
        eq(1, T(() -> customers.pending()).size(), "it is on the pending list");
        LinkView ok = T(() -> customers.approve(co.id(), "sa1"));
        eq("ACTIVE", ok.status(), "approved by another person");
        eq("sa1", ok.approvedBy(), "who is recorded");
        eq("OK", portal("cust1", "portal.account.read", "ACC-555-1", null).code(), "the account is now reachable");
        rejects("INVALID_STATE", () -> customers.approve(co.id(), "sa1"), "approving twice");

        LinkView rej = T(() -> customers.create(uid, new CreateLinkRequest("ACCOUNT", "GUARANTOR", "ACC-666-1", "C-666", null, null), "ua1"));
        T(() -> customers.reject(rej.id(), "not verified", "sa1"));
        eq("ACCOUNT_NOT_LINKED", portal("cust1", "portal.account.read", "ACC-666-1", null).code(), "a rejected link gives nothing");

        T(() -> customers.revoke(co.id(), "left the loan", "ua1"));
        eq("ACCOUNT_NOT_LINKED", portal("cust1", "portal.account.read", "ACC-555-1", null).code(), "a revoked link stops access at the next check");
        rejects("INVALID_STATE", () -> customers.revoke(co.id(), "again", "ua1"), "revoking twice");

        // dated delegate
        LocalDate today = LocalDate.ofInstant(now(), ZoneOffset.UTC);
        LinkView del = T(() -> customers.create(uid, new CreateLinkRequest("ACCOUNT", "DELEGATE", "ACC-777-1", "C-777", today, today.plusDays(1)), "ua1"));
        T(() -> customers.approve(del.id(), "sa1"));
        eq("OK", portal("cust1", "portal.account.read", "ACC-777-1", null).code(), "a delegate link works within its dates");
        advance(Duration.ofDays(2));
        eq("ACCOUNT_NOT_LINKED", portal("cust1", "portal.account.read", "ACC-777-1", null).code(), "and stops by itself after its end date");

        // offboarding a customer revokes every link and ends sessions
        T(() -> customers.create(row("cust3").id(), new CreateLinkRequest("CUSTOMER", "OWNER", null, null, null, null), "ua1"));
        eq("OK", portal("cust3", "portal.account.read", null, "C-300").code(), "cust3 reaches own accounts");
        T(() -> userService.offboard(row("cust3").id(), "ua1"));
        eq("USER_NOT_ACTIVE", portal("cust3", "portal.account.read", null, "C-300").code(), "an offboarded customer reaches nothing");
        eq(0L, count("SELECT count(*) FROM customer_link WHERE user_id = ? AND status IN ('ACTIVE','PENDING_APPROVAL')", row("cust3").id()), "and holds no live link");
        eq(1L, detailCount("USER_OFFBOARD_DETAIL", "cust3", "\"linksRevoked\":1"), "the offboarding audit row counts the links it revoked");
    }

    // ------------------------------------------------------------------ self view
    static void selfView() {
        section("self view");
        SelfService.MeView me = T(() -> selfService.me(person("pa1", true)));
        eq("pa1", me.username(), "me: username");
        eq("STAFF", me.kind(), "me: kind");
        check(me.roles().contains("PRODUCT_APPROVER") && me.permissions().contains("loan.product.approve"), "me: roles and permissions");
        check(me.mfaEnabled() && me.mfaRequiredByRole(), "me: MFA state");
        check(me.tokenMfaAt() != null, "me: the token's second-factor time is echoed");
        SelfService.MeView c = T(() -> selfService.me(person("cust1", false)));
        eq("C-100", c.customerId(), "me: customer id for a customer");
        check(c.permissions().contains("portal.account.read"), "me: customer permissions");
        rejects("NOT_A_PERSON", () -> selfService.me(service("lcm-svc")), "a service account has no profile");
    }

    // ------------------------------------------------------------------ audit chain
    static void auditChain() {
        section("audit chain");
        AuditService.VerifyResult v = audit.verify(null, null);
        check(v.ok(), "the whole chain verifies" + (v.ok() ? "" : ": " + v.reason() + " at " + v.firstBrokenId()));
        eq(count("SELECT count(*) FROM audit_log"), v.rowsChecked(), "and every row was checked");

        // concurrent writers: the chain stays unbroken
        long before = count("SELECT count(*) FROM audit_log");
        Scenario1.runParallel(4, i -> {
            for (int k = 0; k < 10; k++) {
                final int kk = k;
                T(() -> { audit.record("HARNESS_NOISE", "TEST", "t" + i + "-" + kk, "SUCCESS", "n", kk); return null; });
            }
        });
        eq(before + 40, count("SELECT count(*) FROM audit_log"), "forty concurrent audit rows were written");
        v = audit.verify(null, null);
        check(v.ok(), "the chain still verifies after concurrent writers" + (v.ok() ? "" : ": " + v.reason() + " at " + v.firstBrokenId()));
        // a time range
        v = audit.verify(now().minus(Duration.ofDays(400)), now().plus(Duration.ofDays(1)));
        check(v.ok(), "a range verifies");
        v = audit.verify(now().plus(Duration.ofDays(100)), null);
        check(v.ok() && v.rowsChecked() == 0, "an empty range verifies trivially");

        // the table refuses change
        for (String sql : new String[]{"UPDATE audit_log SET actor = 'x' WHERE audit_id = 1", "DELETE FROM audit_log WHERE audit_id = 1", "TRUNCATE audit_log"}) {
            try { R(() -> jdbc.update(sql)); check(false, "should be blocked: " + sql); }
            catch (RuntimeException e) { check(true, "blocked: " + sql); }
        }
        eq(before + 40, count("SELECT count(*) FROM audit_log"), "nothing changed");

        // tamper with the triggers disabled (what a database administrator could do): verification must notice
        long mid = count("SELECT audit_id FROM audit_log WHERE action = 'USER_CREATED' AND target_id = 'pm1'");
        String original = jdbc.queryForObject("SELECT detail FROM audit_log WHERE audit_id = ?::bigint", String.class, String.valueOf(mid));
        R(() -> jdbc.execute("ALTER TABLE audit_log DISABLE TRIGGER trg_audit_log_no_update"));
        R(() -> jdbc.update("UPDATE audit_log SET detail = ? WHERE audit_id = ?::bigint", original.replace("STAFF", "CUSTOMER") + " ", String.valueOf(mid)));
        v = audit.verify(null, null);
        check(!v.ok(), "a changed row is detected");
        eq((Long) mid, v.firstBrokenId(), "and the first broken row is named");
        R(() -> jdbc.update("UPDATE audit_log SET detail = ? WHERE audit_id = ?::bigint", original, String.valueOf(mid)));
        // also: a deleted row in the middle
        R(() -> jdbc.execute("ALTER TABLE audit_log DISABLE TRIGGER trg_audit_log_no_update"));
        String[] row = new String[1];
        long victim = mid + 3;
        R(() -> jdbc.execute("CREATE TEMP TABLE IF NOT EXISTS audit_backup AS SELECT * FROM audit_log WHERE false"));
        R(() -> jdbc.update("INSERT INTO audit_backup SELECT * FROM audit_log WHERE audit_id = ?::bigint", String.valueOf(victim)));
        R(() -> jdbc.update("DELETE FROM audit_log WHERE audit_id = ?::bigint", String.valueOf(victim)));
        v = audit.verify(null, null);
        check(!v.ok(), "a deleted row is detected");
        R(() -> jdbc.update("INSERT INTO audit_log SELECT * FROM audit_backup"));
        R(() -> jdbc.execute("ALTER TABLE audit_log ENABLE TRIGGER trg_audit_log_no_update"));
        v = audit.verify(null, null);
        check(v.ok(), "after restoring the rows the chain verifies again" + (v.ok() ? "" : ": " + v.reason() + " at " + v.firstBrokenId()));
        try { R(() -> jdbc.update("UPDATE audit_log SET actor = 'x' WHERE audit_id = 1")); check(false, "trigger back on"); } catch (RuntimeException e) { check(true, "the trigger is back on"); }
    }

    // ------------------------------------------------------------------ sweep
    static void sweepAndPurge() {
        section("sweep");
        String old = java.time.LocalDateTime.ofInstant(now().minus(Duration.ofDays(3)), ZoneOffset.UTC).toString().replace('T', ' ');
        String fresh = java.time.LocalDateTime.ofInstant(now().plus(Duration.ofHours(8)), ZoneOffset.UTC).toString().replace('T', ' ');
        String hourAgo = java.time.LocalDateTime.ofInstant(now().minus(Duration.ofHours(1)), ZoneOffset.UTC).toString().replace('T', ' ');
        R(() -> jdbc.update("DELETE FROM oauth2_authorization"));
        for (String[] r : new String[][]{{"p-old", old}, {"p-fresh", fresh}, {"p-recent", hourAgo}}) {
            R(() -> jdbc.update("INSERT INTO oauth2_authorization (id, registered_client_id, principal_name, authorization_grant_type, access_token_value, access_token_expires_at, refresh_token_value, refresh_token_expires_at) VALUES (?,?,?,?,?,?,?,?)",
                    r[0], "admin-console", "pm1", "authorization_code", "t", r[1], "r", r[1]));
        }
        SweepService.Result res = T(() -> sweep.run());
        eq(1, res.purgedAuthorizations(), "only authorizations that expired over a day ago are purged");
        eq(2L, count("SELECT count(*) FROM oauth2_authorization"), "fresh and recent ones stay");
        SweepService.Result again = T(() -> sweep.run());
        eq(0, again.purgedAuthorizations(), "the sweep is idempotent");
        // an expired approval is picked up by the sweep too
        ActionView e = Scenario2.submit("pm1", "LOAN_PRODUCT_CHANGE", "SWEEP1", Scenario2.P1, null, null, null);
        advance(Duration.ofHours(80));
        SweepService.Result r3 = T(() -> sweep.run());
        check(r3.expiredActions() >= 1, "the sweep expires pending actions");
        eq("EXPIRED", T(() -> approvals.get(e.id())).status(), "the action is expired");
        check(r3.fannedOut() >= 1, "and fans out the events");
    }

    // ------------------------------------------------------------------ encryption key rotation
    static void encryptionKeyRotation() {
        section("encryption key rotation");
        R(() -> keys.ensureActiveKey());
        Scenario1.Enr pa1 = Scenario1.ENROLLED.get("pa1");
        T(() -> mfa.enrol("au1"));   // a pending (unconfirmed) secret
        long au1 = row("au1").id();
        ReencryptService.Result r = T(() -> reencrypt.run(crypto2, crypto));
        check(r.mfaSecrets() >= 1 && r.signingKeys() >= 1 && r.webhookSecrets() >= 1, "secrets of every kind were re-encrypted (" + r + ")");
        eq(0, r.unreadable(), "nothing was unreadable");
        UserRowLite pa = new UserRowLite(row("pa1"));
        eq(pa1.secret, crypto2.decrypt(pa.mfaSecretEnc, "mfa:" + pa.id), "an MFA secret now opens with the new key");
        check(!crypto.canDecrypt(pa.mfaSecretEnc, "mfa:" + pa.id), "and no longer with the old one");
        check(crypto2.canDecrypt(row("au1").mfaPendingEnc(), "mfa-pending:" + au1), "pending enrolments too");
        String sub = jdbc.queryForObject("SELECT secret_enc FROM webhook_subscription WHERE sub_id = ?::bigint", String.class, String.valueOf(aId));
        eq(aSecret, crypto2.decrypt(sub, "webhook"), "a webhook secret now opens with the new key");
        KeyService withNew = new KeyService(keyRepo, crypto2, audit, settings, clock);
        advance(Duration.ofSeconds(31));
        check(withNew.active().privateKey() != null, "the active signing key can be loaded with the new key");
        ReencryptService.Result r2 = T(() -> reencrypt.run(crypto2, crypto));
        eq(0, r2.mfaSecrets() + r2.signingKeys() + r2.webhookSecrets(), "running it again changes nothing");
        eq(1L, audits("ENCRYPTION_KEY_ROTATED", "iam", "SUCCESS"), "the rotation is audited once");
        ReencryptService.Result wrong = T(() -> reencrypt.run(new com.bank.lending.iam.crypto.SecretCrypto(fill(33)), crypto));
        check(wrong.unreadable() > 0, "with the wrong previous key the secrets are reported unreadable, not destroyed");
        check(crypto2.canDecrypt(row("pa1").mfaSecretEnc(), "mfa:" + pa.id), "and they are untouched");
        eq(1L, audits("ENCRYPTION_KEY_ROTATED", "iam", "FAILURE"), "the failure is audited");
    }

    // ------------------------------------------------------------------ nobody can administer: restore the bootstrap account from configuration
    static void breakGlass() {
        section("recovery when nobody can administer");
        long before = audits("BOOTSTRAP_RECOVERY", null);
        eq(false, T(() -> bootstrap.run()), "with an active administrator the bootstrap settings do nothing");
        long boot = row("bootstrap").id(), ua = row("ua1").id();
        T(() -> userService.suspend(boot, "ua1"));
        eq(false, T(() -> bootstrap.run()), "one administrator left: nothing happens");
        T(() -> userService.suspend(ua, "bootstrap"));
        String savedPw = settings.bootstrapPassword;
        settings.bootstrapPassword = "";
        eq(false, T(() -> bootstrap.run()), "nobody can administer but no settings are present: nothing happens");
        eq("SUSPENDED", row("bootstrap").status(), "the bootstrap account stays suspended without settings");
        settings.bootstrapPassword = savedPw;
        eq(true, T(() -> bootstrap.run()), "with the settings present the bootstrap account is restored");
        UserRowCheck u = new UserRowCheck(row("bootstrap"));
        eq("ACTIVE", u.status, "it is active again");
        eq(false, u.mfa, "its second factor was cleared");
        eq(3L, count("SELECT count(*) FROM user_role WHERE user_id = ? AND ended_at IS NULL", boot), "it holds the three identity roles");
        eq(before + 1, audits("BOOTSTRAP_RECOVERY", null), "the recovery is audited");
        eq(Authenticator.Outcome.MFA_ENROLMENT_REQUIRED, login("bootstrap", settings.bootstrapPassword, null).outcome(), "it signs in with the configured password and must enrol again");
        eq(false, T(() -> bootstrap.run()), "once someone can administer, the settings do nothing again");
        T(() -> userService.reinstate(ua));
        eq("ACTIVE", row("ua1").status(), "the named administrator is reinstated afterwards");
    }

    static class UserRowCheck {
        final String status; final boolean mfa;
        UserRowCheck(com.bank.lending.iam.user.UserRow u) { status = u.status(); mfa = u.mfaEnabled(); }
    }

    static class UserRowLite {
        final long id; final String mfaSecretEnc;
        UserRowLite(com.bank.lending.iam.user.UserRow u) { id = u.id(); mfaSecretEnc = u.mfaSecretEnc(); }
    }
}
