package org.springframework.security.oauth2.jwt;
public class JwsHeader { public static class Builder { public Builder keyId(String k){return this;} } }
