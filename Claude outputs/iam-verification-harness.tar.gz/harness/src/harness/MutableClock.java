package harness;

import java.time.*;

/** A clock the scenario can move forward. */
public class MutableClock extends Clock {
    private volatile Instant now;
    public MutableClock(Instant start) { this.now = start; }
    public void advance(Duration d) { now = now.plus(d); }
    public void set(Instant i) { now = i; }
    @Override public ZoneId getZone() { return ZoneOffset.UTC; }
    @Override public Clock withZone(ZoneId zone) { return this; }
    @Override public Instant instant() { return now; }
}
