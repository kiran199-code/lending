package org.springframework.security.oauth2.server.resource.authentication;
import org.springframework.security.core.*;
import org.springframework.security.oauth2.jwt.Jwt;
public class JwtAuthenticationToken implements Authentication {
    private final Jwt jwt;
    public JwtAuthenticationToken(Jwt jwt) { this.jwt = jwt; }
    public Jwt getToken() { return jwt; }
    public Object getPrincipal() { return jwt; }
    public String getName() { return "jwt"; }
    public java.util.Collection<? extends GrantedAuthority> getAuthorities(){return java.util.List.of();} public Object getCredentials(){return null;} public Object getDetails(){return null;} public boolean isAuthenticated(){return true;}
}
