package org.springframework.jdbc.core;
import java.sql.*;
@FunctionalInterface public interface RowCallbackHandler { void processRow(ResultSet rs) throws SQLException; }
