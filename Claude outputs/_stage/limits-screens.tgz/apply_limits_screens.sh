#!/bin/bash
# Run from the repository root (C:\Kiran\development\Lending) in Git Bash / WSL:  bash apply_limits_screens.sh
# Copies the changed files over the working tree. Nothing is committed. Review with: git status / git diff
set -e
HERE="$(cd "$(dirname "$0")" && pwd)"
ROOT="${1:-$PWD}"
[ -f "$ROOT/pom.xml" ] || { echo "Run this from the repository root (or pass it as the first argument)"; exit 1; }
cp -r "$HERE/repo/." "$ROOT/"
echo "Copied. Now: cd $ROOT && git status --short"
