package org.springframework.jdbc.core;
import java.util.List;
public class JdbcTemplate {
  public <T> T query(String sql, ResultSetExtractor<T> rse, Object... args) { return null; }
  public void query(String sql, RowCallbackHandler rch, Object... args) {}
  public <T> List<T> query(String sql, RowMapper<T> rowMapper, Object... args) { return null; }
  public <T> T queryForObject(String sql, Class<T> requiredType, Object... args) { return null; }
  public <T> T queryForObject(String sql, RowMapper<T> rowMapper, Object... args) { return null; }
  public int update(String sql, Object... args) { return 0; }
  public int[] batchUpdate(String sql, List<Object[]> batchArgs) { return null; }
  public void execute(String sql) {}
  public <T> T execute(ConnectionCallback<T> action) { return null; }
}
