package org.springframework.web.bind;
public class MissingRequestHeaderException extends RuntimeException { public String getHeaderName(){return "";} }
