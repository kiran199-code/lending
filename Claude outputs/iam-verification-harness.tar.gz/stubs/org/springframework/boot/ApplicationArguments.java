package org.springframework.boot;
public interface ApplicationArguments {}
