package org.springframework.scheduling.annotation;
import java.lang.annotation.*;
@Retention(RetentionPolicy.RUNTIME) public @interface Scheduled { String cron() default ""; }
