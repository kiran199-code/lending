package com.nimbusds.jose;
public class JWSAlgorithm extends Algorithm { public static final JWSAlgorithm RS256 = new JWSAlgorithm(); }
