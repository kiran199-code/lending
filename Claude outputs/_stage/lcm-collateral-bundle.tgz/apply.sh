#!/bin/bash
# Run from the repo root. Overlays the changed module trees, never commits.
set -e
D="$(cd "$(dirname "$0")" && pwd)"; R="$(pwd)"
tar xzf "$D/lending-service-src.tgz" -C lending-service-db-layer/lending-service
tar xzf "$D/lcm.tgz" -C .
tar xzf "$D/admin.tgz" -C .
tar xzf "$D/e2e.tgz" -C .
python3 - "$D" <<'PY'
import sys,re
d=sys.argv[1]
e=open(d+'/changelog_entry.md').read().rstrip()+"\n"
s=open('CHANGELOG.md').read()
if 'LCM is the single source of truth' not in s:
    s=s.replace("### Added\n","### Added\n"+e,1); open('CHANGELOG.md','w').write(s)
r=open('README.md').read()
r=r.replace("loan accounts, mortgage collateral, amortization","loan accounts (collateral and limits live in the separate LCM service), amortization",1)
r=r.replace("payments, mortgage and the customer statement PDF","payments, the facility and collateral cover and the customer statement PDF",1)
open('README.md','w').write(r)
PY
echo "Files in the repo that no longer exist in the new trees (review; mortgage web/service/dto are expected):"
for m in "lending-service-db-layer/lending-service/src" ; do
  tar tzf "$D/lending-service-src.tgz" | grep -v '/$' | sed 's#^\./##' | sort > /tmp/new.lst
  (cd lending-service-db-layer/lending-service && find src -type f | sort) | comm -23 - /tmp/new.lst
done
git status --short | grep -v '^??.*docs/\|Claude outputs'
