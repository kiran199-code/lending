import sys, json, datetime, decimal
import psycopg2

conn = psycopg2.connect(dbname="iamtest", options="-c search_path=iam")
conn.autocommit = False

def dec(a):
    t, v = a["t"], a.get("v")
    if t == "null": return None
    if t == "num": return decimal.Decimal(v)
    if t == "int": return int(v)
    if t == "bool": return bool(v)
    if t == "date": return datetime.date.fromisoformat(v)
    return v

def enc(x):
    if x is None: return {"t": "null"}
    if isinstance(x, bool): return {"t": "bool", "v": x}
    if isinstance(x, int): return {"t": "int", "v": str(x)}
    if isinstance(x, decimal.Decimal): return {"t": "num", "v": str(x)}
    if isinstance(x, datetime.datetime): return {"t": "ts", "v": x.isoformat()}
    if isinstance(x, datetime.date): return {"t": "date", "v": x.isoformat()}
    return {"t": "str", "v": str(x)}

cur = conn.cursor()
for line in sys.stdin:
    req = json.loads(line)
    op = req["op"]
    try:
        if op in ("query", "update"):
            cur.execute(req["sql"].replace("?", "%s"), [dec(a) for a in req["args"]])
            if cur.description:
                cols = [d[0] for d in cur.description]
                rows = [[enc(v) for v in r] for r in cur.fetchall()]
            else:
                cols, rows = [], []
            out = {"ok": True, "cols": cols, "rows": rows, "count": cur.rowcount}
        elif op == "commit":
            conn.commit(); out = {"ok": True, "cols": [], "rows": [], "count": 0}
        elif op == "rollback":
            conn.rollback(); out = {"ok": True, "cols": [], "rows": [], "count": 0}
        else:
            out = {"ok": False, "error": "bad op"}
    except Exception as e:
        # like the real driver: the transaction stays in the aborted state until the caller rolls back
        out = {"ok": False, "error": str(e).strip()}
    sys.stdout.write(json.dumps(out) + "\n"); sys.stdout.flush()
