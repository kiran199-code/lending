package org.springframework.security.authentication;
import org.springframework.security.core.*;
public interface AuthenticationProvider { Authentication authenticate(Authentication a) throws AuthenticationException; boolean supports(Class<?> c); }
