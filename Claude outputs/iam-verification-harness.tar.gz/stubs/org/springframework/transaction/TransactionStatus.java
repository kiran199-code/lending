package org.springframework.transaction;
public interface TransactionStatus {}
