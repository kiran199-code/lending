package org.springframework.dao;
public class DuplicateKeyException extends DataIntegrityViolationException { public DuplicateKeyException(String m){super(m);} }
