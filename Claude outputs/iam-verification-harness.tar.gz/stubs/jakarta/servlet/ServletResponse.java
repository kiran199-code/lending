package jakarta.servlet;
public interface ServletResponse { void setContentType(String t); java.io.PrintWriter getWriter() throws java.io.IOException; }
