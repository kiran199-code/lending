package org.springframework.security.core.authority;
import org.springframework.security.core.GrantedAuthority;
public final class SimpleGrantedAuthority implements GrantedAuthority { private final String r; public SimpleGrantedAuthority(String r){this.r=r;} public String getAuthority(){return r;} }
