package org.springframework.security.oauth2.server.authorization.client;
public interface RegisteredClientRepository { void save(RegisteredClient c); RegisteredClient findById(String id); RegisteredClient findByClientId(String clientId); }
