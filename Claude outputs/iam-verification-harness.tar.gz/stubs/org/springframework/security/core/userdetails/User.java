package org.springframework.security.core.userdetails;
import org.springframework.security.core.GrantedAuthority;
public class User { public User(String username, String password, boolean enabled, boolean accountNonExpired, boolean credentialsNonExpired, boolean accountNonLocked, java.util.Collection<? extends GrantedAuthority> authorities){} }
