package org.springframework.transaction.support;
/** Local stub with the shape of Spring 6: default methods, status constants. */
public interface TransactionSynchronization {
  int STATUS_COMMITTED = 0; int STATUS_ROLLED_BACK = 1; int STATUS_UNKNOWN = 2;
  default void afterCommit() {}
  default void afterCompletion(int status) {}
}
