# lending-chit-service: build status

Chit fund microservice for the lending platform. Built in phases from `docs/Chit_Fund_Specification_Prompt_v2.md`.
Last updated 23 Oct 2026. **Phase 1 of 10 is done. Phases 2 to 9 are not started.**

## Phase 0: discovery note

### Assumptions

1. Separate Maven project like `lending-lcm-service`: Java 17, Spring Boot 3.3.2, schema `chit`, history table `chit_schema_history`, port 8086, API root `/api/v1/chit`, variables prefixed `CHIT_`.
2. Own double-entry journal (no reuse of the lending accounting engine). Events by table plus pull feed; Kafka only as an optional extension.
3. Operator screens go into the existing React admin console; subscriber screens wait for the customer portal.
4. Cycle dates follow the platform business date from lending-service. A customer is a `customerId` number.
5. Rounding is HALF_UP at 2 decimals. Percentages are written as 5 for 5%. Late fees count calendar days.
6. Rules can be edited only while a group is DRAFT or OPEN_FOR_ENROLMENT; they are frozen from FULL onward.
7. A standard chit has `cycleCount = ticketCount`, so every ticket wins exactly once. The validator enforces it.
8. Group `FULL` may go back to `OPEN_FOR_ENROLMENT` when a ticket is withdrawn before activation.
9. Ticket `TRANSFERRED` is a transient state while a transfer awaits approval; the ticket then returns to ACTIVE or PRIZED with a new subscriber link. A cured defaulter returns to PRIZED if it had won, otherwise ACTIVE.
10. `ROLL_OVER_CYCLE` sends an AUCTION_OPEN cycle back to COLLECTION_OPEN with the calendar extended.
11. No-bid handling: LOTTERY draws a winner at the minimum discount; FOREMAN_DEFAULT_DISCOUNT draws a winner at the foreman's default discount (needs `foremanDefaultDiscountPct`).

### Open questions for you

1. Is `TRANSFERRED` as a transient state right, or do you want the old ticket record closed and a new one opened?
2. With `NON_PRIZED_ONLY`, does the winner of the current cycle share that cycle's dividend? (The calculator takes the list of beneficiaries from the caller, so either works; the service must choose.)
3. Exit of a non-prized ticket: refund paid contributions less penalty, or require a replacement subscriber? The journal for it waits for this answer (Phase 6).
4. When the pool bears the loss of a write-off, who absorbs it (reduce later dividends, or the foreman)? Needed for the Phase 6 journals.
5. Late fees on calendar days is assumed. Business days instead?
6. Is a strict `cycleCount = ticketCount` acceptable, or do you want shorter or longer terms?

### Mismatches between the prompt and the repo

- The prompt's source description said Angular; the admin console is React 18 / Vite / TypeScript. Prompt v2 already follows the repo.
- Port 8083 looks unused; 8086 is used here. Check on your side.
- The root `pom.xml` lists five modules; this one is **not** added yet (Phase 2).

### Proposed package structure

```
com.bank.lending.chit
  common/        Money, ChitException, ConfigInvalidException, RuleViolation          (Phase 1, built)
  domain/        enums and statuses                                                   (Phase 1, built)
  domain/rules/  ChitRules, LateFeeRule, DefaultThreshold, RulesValidator, RulesEditPolicy   (Phase 1, built)
  domain/state/  StateMachine, Lifecycles                                             (Phase 1, built)
  calc/          LargestRemainder, AuctionSettlementCalculator, AllocationEngine,
                 LateFeeCalculator, Draw                                              (Phase 1, built)
  config/        SecurityConfig, ApiExceptionHandler, ChitSettings, ClockConfig       (Phase 2)
  group/ ticket/ cycle/ demand/ payment/ auction/ payout/ dividend/ security/ default/ transfer/ closure/   (Phases 3 to 7)
  ledger/        journal, accounts, templates, trial balance, reconciliation          (Phase 2 onward)
  events/        EventFeed and the event writer                                       (Phase 2)
  maintenance/   status and clear-data                                                (Phase 2)
  portal/        customer-scoped read models                                          (Phase 7)
  platform/      LendingClient (business date, working days, holidays)                (Phase 3)
```

### Journal templates still to review (the core ones are in section 12 of the prompt)

New accounts these need: `FOREMAN_FLOAT_PAYABLE`, `TRANSFER_FEE_INCOME`, `WRITE_OFF_LOSS`, `GUARANTEE_LOSS_EXPENSE`.

| Event | Debit | Credit |
|---|---|---|
| Security applied to a prized defaulter's arrears | SECURITY_DEPOSIT_LIABILITY[t]; then POOL_CASH | SUBSCRIBER_RECEIVABLE[t]; then SECURITY_CASH |
| Foreman covers a shortfall (pays the pool) | POOL_CASH; then FOREMAN_GUARANTEE_RECEIVABLE[t] | FOREMAN_CASH; then SUBSCRIBER_RECEIVABLE[t] |
| Ticket repays a guaranteed amount | FOREMAN_CASH | FOREMAN_GUARANTEE_RECEIVABLE[t] |
| Guarantee written off, foreman bears the loss | GUARANTEE_LOSS_EXPENSE | FOREMAN_GUARANTEE_RECEIVABLE[t] |
| Receivable written off, pool bears the loss (needs open question 4) | WRITE_OFF_LOSS | SUBSCRIBER_RECEIVABLE[t] |
| Foreman floats a liquidity gap | POOL_CASH | FOREMAN_FLOAT_PAYABLE |
| Float repaid from later collections | FOREMAN_FLOAT_PAYABLE | POOL_CASH |
| Ticket transfer fee | FOREMAN_CASH | TRANSFER_FEE_INCOME |
| Cancellation refund of fees | ENROLMENT_FEE_INCOME | FOREMAN_CASH |
| Cancellation refund of a deposit | SECURITY_DEPOSIT_LIABILITY[t] | SECURITY_CASH |
| Exit refund | waits for open question 3 | |

## Phase 1: what is built

Pure Java, no Spring, no database. 33 main classes and 8 test classes with 81 tests, all under `lending-chit-service/`.

| Area | Classes | What it does |
|---|---|---|
| Money | `common/Money` | Scale, percentage, paise conversion; one rounding mode |
| Errors | `common/ChitException`, `ConfigInvalidException`, `RuleViolation` | Stable error codes; no HTTP status in this layer |
| Statuses and rules enums | `domain/*` (16 enums) | Group, ticket and cycle statuses; every configurable choice from the prompt |
| Rules | `domain/rules/ChitRules` (+ builder), `LateFeeRule`, `DefaultThreshold` | The whole configuration as data |
| Validation | `RulesValidator`, `RulesEditPolicy` | 18 error codes, all reported together, including `DISCOUNT_BELOW_COMMISSION` |
| State machines | `domain/state/StateMachine`, `Lifecycles` | Explicit transition tables for group, ticket and cycle; illegal moves refused with `ILLEGAL_TRANSITION` |
| Dividend split | `calc/LargestRemainder` | Exact, deterministic split in paise (ties go to the lower ticket number) |
| Auction money | `calc/AuctionSettlementCalculator`, `AuctionSettlement` | Prize, commission, dividend pool and shares; last cycle with both commission rules; negative pool refused |
| Payments | `calc/AllocationEngine` | Late fees, then oldest arrears, then the current instalment, then advance; custom order; partial payments |
| Late fees | `calc/LateFeeCalculator` | Flat or percent per day, grace, caps, safe to rerun and to catch up |
| Draw | `calc/Draw` | Reproducible winner or full order from a seed (SHA-256 based), with an audit record |

Fixtures from section 17 of the prompt are tests: A (even dividend), B (15,000.07 over 20 tickets: tickets 1 to 7 get 750.01), D (last cycle, both commission rules) and E (minimum discount below the commission is rejected). Fixture C (liquidity gap) belongs to Phase 5.

Not yet built, by design: winner selection and bid validation, the liquidity check, the calendar generator, and everything with a database or HTTP.

## How it was checked, and what was not

- **Done:** every main and test class compiles with `javac` (Java 21 here, source is Java 17 compatible, no preview features). The 81 tests were run with a small stand-in for the JUnit launcher, because Maven Central cannot be reached from the build environment. All passed. A deliberate break of the tie-break rule made 3 tests fail, so the tests do catch that.
- **Not done:** a Maven build, the real JUnit 5 run, the Spring Boot parent and dependency resolution, Testcontainers (not used yet), and any code review by you.
- The tests use only `@Test` and the common `Assertions` methods, so they should run unchanged under JUnit 5. If one does not compile, tell me.

## How to run Phase 1

```
cd lending-chit-service
mvn test
```

Use `mvn test`, not `mvn package`, until Phase 2 adds the application class.

## Next: Phase 2

New module wiring (root pom, Dockerfile, `application.yml`, security, error handler, idempotency, event feed, maintenance), Flyway `V1`, JPA entities, ledger accounts and the reviewed journal templates, and the `render.yaml` and `docker-compose.yml` edits. It needs your answers to open questions 3 and 4 only for Phase 6, so it can start as soon as you approve Phase 1.
