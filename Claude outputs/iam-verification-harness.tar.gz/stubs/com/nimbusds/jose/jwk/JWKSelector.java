package com.nimbusds.jose.jwk;
public class JWKSelector { public java.util.List<JWK> select(JWKSet s){ return java.util.List.of(); } }
