package org.springframework.security.authentication;
import org.springframework.security.core.*;
public class UsernamePasswordAuthenticationToken implements Authentication {
  public static UsernamePasswordAuthenticationToken authenticated(Object p, Object c, java.util.Collection<? extends GrantedAuthority> a){ return new UsernamePasswordAuthenticationToken(); }
  public java.util.Collection<? extends GrantedAuthority> getAuthorities(){return java.util.List.of();} public Object getCredentials(){return null;} public Object getDetails(){return null;} public Object getPrincipal(){return null;} public boolean isAuthenticated(){return true;} public String getName(){return "";} }
