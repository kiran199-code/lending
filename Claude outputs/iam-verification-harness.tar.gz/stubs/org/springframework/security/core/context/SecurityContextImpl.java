package org.springframework.security.core.context;
public class SecurityContextImpl implements SecurityContext {}
