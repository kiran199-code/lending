package com.bank.lending.chit.common;

/**
 * A business-rule failure with a stable machine-readable code. Callers switch on {@code code}, not on the message.
 * It carries no HTTP status on purpose: the calculation and rules code has no Spring dependency. The REST layer
 * (Phase 2) maps a code to a status in one place.
 */
public class ChitException extends RuntimeException {

    private final String code;

    public ChitException(String code, String message) {
        super(message);
        this.code = code;
    }

    public String code() {
        return code;
    }
}
