package org.springframework.web.bind.annotation;
import java.lang.annotation.*;
@Retention(RetentionPolicy.RUNTIME)
public @interface ResponseStatus { org.springframework.http.HttpStatus value() default org.springframework.http.HttpStatus.OK; }
