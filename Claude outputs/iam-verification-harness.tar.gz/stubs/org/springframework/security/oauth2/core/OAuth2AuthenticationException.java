package org.springframework.security.oauth2.core;
public class OAuth2AuthenticationException extends org.springframework.security.core.AuthenticationException { public OAuth2AuthenticationException(OAuth2Error e){super("oauth2");} }
