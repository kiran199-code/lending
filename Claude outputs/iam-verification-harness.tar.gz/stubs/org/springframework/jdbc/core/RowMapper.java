package org.springframework.jdbc.core;
import java.sql.*;
@FunctionalInterface public interface RowMapper<T> { T mapRow(ResultSet rs, int rowNum) throws SQLException; }
