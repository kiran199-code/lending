package org.springframework.http;
public enum HttpStatus { OK(200,"OK"), CREATED(201,"Created"), NO_CONTENT(204,"No Content"), BAD_REQUEST(400,"Bad Request"), UNAUTHORIZED(401,"Unauthorized"), FORBIDDEN(403,"Forbidden"),
  NOT_FOUND(404,"Not Found"), METHOD_NOT_ALLOWED(405,"Method Not Allowed"), CONFLICT(409,"Conflict"), UNPROCESSABLE_ENTITY(422,"Unprocessable Entity"), INTERNAL_SERVER_ERROR(500,"Internal Server Error");
  private final int v; private final String r; HttpStatus(int v,String r){this.v=v;this.r=r;} public int value(){return v;} public String getReasonPhrase(){return r;} }
