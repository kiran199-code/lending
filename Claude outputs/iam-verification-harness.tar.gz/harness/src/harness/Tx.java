package harness;

import java.util.function.Supplier;

/** Stand-in for Spring's @Transactional REQUIRED semantics on top of the per-thread worker connection. */
public class Tx {
    static PgJdbc jdbc;
    static final ThreadLocal<Integer> depth = ThreadLocal.withInitial(() -> 0);

    public static void init(PgJdbc j) {
        jdbc = j;
        org.springframework.transaction.support.TransactionTemplate.RUNNER = new org.springframework.transaction.support.TransactionTemplate.Runner() {
            @SuppressWarnings("unchecked") public <T> T run(Supplier<T> s) { return Tx.run(s); }
        };
    }

    public static <T> T run(Supplier<T> body) {
        int d = depth.get();
        if (d > 0) {
            depth.set(d + 1);
            try { return body.get(); } finally { depth.set(depth.get() - 1); }
        }
        depth.set(1);
        try {
            T r = body.get();
            jdbc.tx("commit");
            return r;
        } catch (RuntimeException | Error e) {
            try { jdbc.tx("rollback"); } catch (RuntimeException ignore) { }
            throw e;
        } finally {
            depth.set(0);
        }
    }

    /** Like @Transactional(noRollbackFor = ex): commits what was done (counters, audit rows) even when the body throws ex. */
    public static <T> T runKeeping(Class<? extends RuntimeException> ex, Supplier<T> body) {
        int d = depth.get();
        if (d > 0) { return body.get(); }
        depth.set(1);
        try {
            T r;
            try {
                r = body.get();
            } catch (RuntimeException e) {
                if (ex.isInstance(e)) { jdbc.tx("commit"); }
                else { try { jdbc.tx("rollback"); } catch (RuntimeException ignore) { } }
                throw e;
            }
            jdbc.tx("commit");
            return r;
        } catch (Error e) {
            try { jdbc.tx("rollback"); } catch (RuntimeException ignore) { }
            throw e;
        } finally {
            depth.set(0);
        }
    }

    public static void run(Runnable body) {
        run(() -> { body.run(); return null; });
    }
}
