package org.springframework.web.method.annotation;
public class MethodArgumentTypeMismatchException extends RuntimeException {}
