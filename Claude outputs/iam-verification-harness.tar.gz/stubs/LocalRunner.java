import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.nio.file.*;
import java.util.*;

public class LocalRunner {
    public static void main(String[] args) throws Exception {
        int pass = 0, fail = 0;
        for (String cn : args) {
            Class<?> c = Class.forName(cn);
            for (Method m : c.getDeclaredMethods()) {
                if (m.getAnnotation(org.junit.jupiter.api.Test.class) == null) continue;
                m.setAccessible(true);
                var ctor = c.getDeclaredConstructor(); ctor.setAccessible(true); Object o = Modifier.isStatic(m.getModifiers()) ? null : ctor.newInstance();
                try { m.invoke(o); pass++; }
                catch (java.lang.reflect.InvocationTargetException e) { fail++; System.out.println("FAIL " + cn + "." + m.getName() + ": " + e.getCause()); e.getCause().printStackTrace(System.out); }
            }
        }
        System.out.println("passed " + pass + ", failed " + fail);
        if (fail > 0) System.exit(1);
    }
}
