package io.micrometer.core.instrument;
public abstract class MeterRegistry { public Counter counter(String name, String... tags){return null;} }
