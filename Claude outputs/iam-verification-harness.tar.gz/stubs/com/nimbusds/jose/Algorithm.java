package com.nimbusds.jose;
public class Algorithm {}
