#!/bin/bash
# Compiles the harness against the stub-compiled main tree (run ../build_check.sh first) and runs it against Postgres db iamtest.
set -e
cd /home/claude/iamsvc
L=/opt/gradle-8.14.3/lib
CP=$(ls $L/jackson-{core,databind,annotations}-2.16.1.jar $L/jackson-datatype-jsr310-2.16.1.jar $L/jackson-datatype-jdk8-2.16.1.jar $L/slf4j-api-1.7.36.jar | tr '\n' ':')
H=harness/out; rm -rf $H; mkdir -p $H
find harness/src -name '*.java' > /tmp/h_src.txt
javac -Xlint:-processing -d $H -cp "out:$CP" @/tmp/h_src.txt 2>&1 | grep -v JAVA_TOOL_OPTIONS | head -${LINES_MAX:-80}
[ "${PIPESTATUS[0]}" = 0 ] || exit 2
./runmig.sh
java -cp "$H:out:$CP" harness.IamPgRun
