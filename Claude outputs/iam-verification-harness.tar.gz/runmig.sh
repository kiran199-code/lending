#!/bin/bash
# applies all migrations to a fresh database "iamtest"
cd /home/claude/iamsvc/lending-iam-service
su postgres -c "psql -q -c 'DROP DATABASE IF EXISTS iamtest' -c 'CREATE DATABASE iamtest'" >/dev/null 2>&1
su postgres -c "psql -q iamtest -c 'CREATE SCHEMA iam'" >/dev/null 2>&1
for f in src/main/resources/db/migration/V*.sql; do
  (echo "SET search_path=iam;"; echo "BEGIN;"; cat $f; echo "COMMIT;") | su postgres -c "psql -v ON_ERROR_STOP=1 -q iamtest" 2>&1 | sed "s|^|$f: |" | tail -5
done
