package org.springframework.transaction.support;
import java.util.*;
/** Local stub of the part of Spring's API the limits code and its tests use. */
public abstract class TransactionSynchronizationManager {
  private static final ThreadLocal<List<TransactionSynchronization>> SYNCS = new ThreadLocal<>();
  public static boolean isSynchronizationActive() { return SYNCS.get() != null; }
  public static void initSynchronization() { if (SYNCS.get() != null) throw new IllegalStateException("Cannot activate transaction synchronization - already active"); SYNCS.set(new ArrayList<>()); }
  public static void registerSynchronization(TransactionSynchronization s) {
    if (SYNCS.get() == null) throw new IllegalStateException("Transaction synchronization is not active");
    SYNCS.get().add(s);
  }
  public static List<TransactionSynchronization> getSynchronizations() {
    if (SYNCS.get() == null) throw new IllegalStateException("Transaction synchronization is not active");
    return Collections.unmodifiableList(new ArrayList<>(SYNCS.get()));
  }
  public static void clearSynchronization() { if (SYNCS.get() == null) throw new IllegalStateException("Cannot deactivate transaction synchronization - not active"); SYNCS.remove(); }
}
