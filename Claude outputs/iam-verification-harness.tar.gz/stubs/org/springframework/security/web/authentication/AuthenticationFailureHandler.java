package org.springframework.security.web.authentication;
import jakarta.servlet.http.*; import org.springframework.security.core.AuthenticationException;
public interface AuthenticationFailureHandler { void onAuthenticationFailure(HttpServletRequest rq, HttpServletResponse rs, AuthenticationException e) throws java.io.IOException, jakarta.servlet.ServletException; }
