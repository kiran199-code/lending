package harness;

import com.bank.lending.iam.access.RoleDtos.*;
import com.bank.lending.iam.auth.Authenticator;
import com.bank.lending.iam.common.*;
import com.bank.lending.iam.keys.KeyService;
import com.bank.lending.iam.user.UserDtos.*;
import com.bank.lending.iam.user.UserRow;

import java.time.Duration;
import java.util.*;

import static harness.IamPgRun.*;

/** Bootstrap, signing keys, users and roles, sign-in, lockout, second factor. */
public class Scenario1 {
    static void run() {
        bootstrapAndKeys();
        usersAndRoles();
        signIn();
        lockout();
        secondFactor();
    }

    static void bootstrapAndKeys() {
        section("bootstrap and signing keys");
        eq(true, T(() -> bootstrap.run()), "bootstrap creates the first administrator");
        eq(false, T(() -> bootstrap.run()), "bootstrap does nothing the second time");
        UserRow b = row("bootstrap");
        check(b.bootstrap(), "bootstrap user is flagged");
        eq("ACTIVE", b.status(), "bootstrap user is active");
        eq(3L, count("SELECT count(*) FROM user_role WHERE user_id = ?", b.id()), "bootstrap holds the three identity roles");
        check(b.passwordHash() != null && !b.passwordHash().contains("B00tstrap"), "bootstrap password is stored hashed");
        eq(1L, audits("USER_CREATED", "bootstrap"), "bootstrap creation is audited");
        var cli = T(() -> clientRepo.find("iam-admin-cli")).orElse(null);
        check(cli != null && cli.isPublic() && cli.secretHash() == null, "the command-line sign-in client exists, public, without a secret");
        check(cli != null && cli.redirectUris().equals(List.of("http://127.0.0.1:8765/callback")), "and redirects only to the loopback address");
        check(cli != null && cli.grantTypes().contains("authorization_code"), "with the authorization code grant");
        eq(1L, count("SELECT count(*) FROM oauth_client WHERE client_id = 'iam-admin-cli'"), "created once");

        // the bootstrap user holds MFA-required roles: sign-in demands enrolment, and the roles do nothing until then
        Authenticator.Result r = login("bootstrap", "B00tstrap-Passw0rd!x", null);
        eq(Authenticator.Outcome.MFA_ENROLMENT_REQUIRED, r.outcome(), "bootstrap must enrol a second factor");
        check(person("bootstrap", false).permissions().isEmpty(), "MFA-required roles give nothing before enrolment");
        List<String> sec = enrolMfa("bootstrap");
        check(!person("bootstrap", false).permissions().isEmpty(), "roles take effect once MFA is on");
        check(sec.size() - 1 >= 8, "recovery codes are issued (at least 8)");
        advance(Duration.ofSeconds(35));   // the enrolment code's step is spent
        r = login("bootstrap", "B00tstrap-Passw0rd!x", otp(sec.get(0)));
        eq(Authenticator.Outcome.SUCCESS, r.outcome(), "bootstrap signs in with a code");
        check(r.mfaAt() != null, "the token would carry mfa_at");
        bootstrapSecret = sec.get(0);

        T(() -> { keys.ensureActiveKey(); return null; });
        T(() -> { keys.ensureActiveKey(); return null; });
        eq(1L, count("SELECT count(*) FROM signing_key"), "one signing key after two starts");
        List<KeyService.Published> pub = keys.published();
        eq(1, pub.size(), "one published key");
        check(pub.get(0).active() && pub.get(0).privateKey() != null, "the active key can sign");
        String enc = jdbc.queryForObject("SELECT private_enc FROM signing_key WHERE status = 'ACTIVE'", String.class);
        check(enc != null && !enc.contains("PRIVATE") && !enc.contains("MII"), "the private key is stored encrypted");
        String oldKid = pub.get(0).keyId();

        KeyService.KeyView nk = T(() -> keys.rotate());
        check(!nk.keyId().equals(oldKid), "rotation makes a new key");
        advance(Duration.ofSeconds(31));   // past the key cache
        pub = keys.published();
        eq(2, pub.size(), "both keys are published after rotation");
        long actives = pub.stream().filter(KeyService.Published::active).count();
        eq(1L, actives, "exactly one signs");
        check(pub.stream().filter(p -> p.keyId().equals(oldKid)).allMatch(p -> p.privateKey() == null), "the retired key is public-only");
        eq(nk.keyId(), keys.active().keyId(), "the new key is the active one");
        eq(1L, audits("SIGNING_KEY_ROTATED", nk.keyId()), "rotation is audited");

        advance(Duration.ofHours(25));
        eq(1, T(() -> keys.dropExpired()), "the private half of the expired retired key is dropped");
        advance(Duration.ofSeconds(31));
        eq(1, keys.published().size(), "the expired key is no longer published");
        eq(0, T(() -> keys.dropExpired()), "nothing more to drop");
        // a concurrent first start: two instances insert an active key at once, one wins
        R(() -> jdbc.update("UPDATE signing_key SET status = 'RETIRED', retired_at = ?, retire_after = ? WHERE status = 'ACTIVE'", now().toString(), now().minusSeconds(1).toString()));
        int[] ok = new int[1];
        runParallel(2, i -> {
            try { Tx.run(() -> keys.ensureActiveKey()); ok[0]++; } catch (RuntimeException e) { /* the loser may fail on the unique index; that is the design */ }
        });
        eq(1L, count("SELECT count(*) FROM signing_key WHERE status = 'ACTIVE'"), "two instances starting together leave one active key");
        advance(Duration.ofSeconds(31));
    }

    static String bootstrapSecret;
    static final String PW3 = "Th1rd-Str0ng-Passw0rd";

    static void usersAndRoles() {
        section("users and roles");
        String[][] people = {
                {"ua1", "IAM_USER_ADMIN"}, {"aa1", "IAM_ACCESS_ADMIN"}, {"sx1", "IAM_SECURITY_ADMIN"}, {"sa1", "SECURITY_APPROVER"}, {"au1", "AUDITOR"},
                {"lo1", "LOAN_OFFICER"}, {"la1", "LOAN_APPROVER"}, {"pm1", "PRODUCT_MANAGER"}, {"pa1", "PRODUCT_APPROVER"}, {"pa2", "PRODUCT_APPROVER"},
                {"lcmm1", "LCM_MAKER"}, {"lcmc1", "LCM_CHECKER"}
        };
        for (String[] p : people) staff(p[0], p[1]);
        eq("ACTIVE", row("pm1").status(), "a user who changed the temporary password is active");
        check(!row("pm1").mustChangePassword(), "must-change flag cleared");
        eq(1L, audits("PASSWORD_CHANGED", "pm1"), "password change is audited");
        eq(1L, audits("USER_CREATED", "pm1"), "user creation is audited");
        eq(1L, audits("ROLES_ASSIGNED", "pm1"), "role assignment is audited");

        // refusals
        rejects("USERNAME_TAKEN", () -> userService.create(new CreateUserRequest("PM1", "STAFF", "Dup", "d@x.test", null, null), "bootstrap"), "usernames are unique ignoring case");
        rejects("CUSTOMER_ID_REQUIRED", () -> userService.create(new CreateUserRequest("cust.x", "CUSTOMER", "C", "c@x.test", null, null), "bootstrap"), "a customer needs a customer id");
        rejects("VALIDATION_FAILED", () -> userService.create(new CreateUserRequest("st.x", "STAFF", "S", "s@x.test", null, "C-1"), "bootstrap"), "staff has no customer id");
        rejects("VALIDATION_FAILED", () -> userService.create(new CreateUserRequest("a b", "STAFF", "S", "s@x.test", null, null), "bootstrap"), "bad username");
        long pm1 = row("pm1").id();
        rejects("ROLE_KIND_MISMATCH", () -> userService.assignRoles(pm1, new AssignRolesRequest(List.of(new RoleGrantRequest("CUSTOMER_SELF", null, null))), "bootstrap"), "a staff user cannot hold a customer role");
        rejects("UNKNOWN_ROLE", () -> userService.assignRoles(pm1, new AssignRolesRequest(List.of(new RoleGrantRequest("NOPE", null, null))), "bootstrap"), "unknown role");
        rejects("SOD_CONFLICT", () -> userService.assignRoles(pm1, new AssignRolesRequest(List.of(new RoleGrantRequest("PRODUCT_MANAGER", null, null), new RoleGrantRequest("PRODUCT_APPROVER", null, null))), "bootstrap"),
                "maker and checker roles cannot be held together");
        rejects("SOD_CONFLICT", () -> userService.assignRoles(pm1, new AssignRolesRequest(List.of(new RoleGrantRequest("IAM_USER_ADMIN", null, null), new RoleGrantRequest("IAM_ACCESS_ADMIN", null, null))), "bootstrap"),
                "creating users and granting access cannot be held together");
        rejects("SELF_ACTION_NOT_ALLOWED", () -> userService.assignRoles(pm1, new AssignRolesRequest(List.of()), "pm1"), "nobody changes their own roles");
        rejects("SELF_ACTION_NOT_ALLOWED", () -> userService.suspend(pm1, "pm1"), "nobody suspends themselves");
        eq(1L, count("SELECT count(*) FROM user_role WHERE user_id = ? AND ended_at IS NULL", pm1), "refused role changes left the roles alone");
        rejects("VALIDATION_FAILED", () -> userService.assignRoles(pm1, new AssignRolesRequest(List.of(new RoleGrantRequest("PRODUCT_MANAGER", null, null), new RoleGrantRequest("PRODUCT_MANAGER", null, null))), "bootstrap"), "a role listed twice");

        // a refused change rolls back everything it wrote, including its audit row
        long before = count("SELECT count(*) FROM audit_log");
        rejects("SOD_CONFLICT", () -> userService.assignRoles(pm1, new AssignRolesRequest(List.of(new RoleGrantRequest("PRODUCT_MANAGER", null, null), new RoleGrantRequest("PRODUCT_APPROVER", null, null))), "bootstrap"), "again");
        eq(before, count("SELECT count(*) FROM audit_log"), "a refused role change writes no audit row");

        // scopes
        T(() -> userService.assignScopes(pm1, new AssignScopesRequest(List.of(new ScopeRequest("BRANCH", "B001"), new ScopeRequest("CURRENCY", "INR"))), "bootstrap"));
        AccessView av = T(() -> userService.accessOf(pm1));
        eq(List.of("B001"), av.scopes().get("BRANCH"), "branch scope stored");
        eq(List.of("INR"), av.scopes().get("CURRENCY"), "currency scope stored");
        check(!av.scopes().containsKey("PRODUCT"), "no product scope means unrestricted");
        rejects("VALIDATION_FAILED", () -> userService.assignScopes(pm1, new AssignScopesRequest(List.of(new ScopeRequest("BRANCH", "*"), new ScopeRequest("BRANCH", "B001"))), "bootstrap"), "star next to named values is refused");
        T(() -> userService.assignScopes(pm1, new AssignScopesRequest(List.of()), "bootstrap"));
        check(T(() -> userService.accessOf(pm1)).scopes().isEmpty(), "scopes cleared");

        // roles: definition, retirement, permission edits
        T(() -> roles.create(new CreateRoleRequest("REPORT_VIEWER", "Report viewer", "STAFF", "reads", false, List.of("loan.account.read", "loan.product.read"))));
        rejects("ROLE_EXISTS", () -> roles.create(new CreateRoleRequest("REPORT_VIEWER", "Dup", "STAFF", null, false, List.of())), "role codes are unique");
        rejects("UNKNOWN_PERMISSION", () -> roles.create(new CreateRoleRequest("BAD_ROLE", "Bad", "STAFF", null, false, List.of("no.such.perm"))), "unknown permission");
        rejects("PERMISSION_KIND_MISMATCH", () -> roles.create(new CreateRoleRequest("BAD_ROLE2", "Bad", "CUSTOMER", null, false, List.of("loan.account.create"))), "staff-only permission on a customer role");
        rejects("SOD_CONFLICT", () -> roles.create(new CreateRoleRequest("BAD_ROLE3", "Bad", "STAFF", null, false, List.of("loan.product.manage", "loan.product.approve"))), "both sides of a rule in one role");
        eq(0L, count("SELECT count(*) FROM role WHERE role_code IN ('BAD_ROLE','BAD_ROLE2','BAD_ROLE3')"), "refused roles are not left behind");
        rejects("SYSTEM_ROLE", () -> roles.replacePermissions("LOAN_OFFICER", new ReplacePermissionsRequest(List.of("loan.account.read"))), "system roles are fixed");
        rejects("SYSTEM_ROLE", () -> roles.update("LOAN_OFFICER", new UpdateRoleRequest("x", null, false, "ACTIVE")), "system roles are fixed (update)");
        staff("rv1", "REPORT_VIEWER");
        // adding the maker permission to a role whose holder is also a checker would break the holder's separation of duties
        T(() -> roles.create(new CreateRoleRequest("PROD_EDIT", "Product edit", "STAFF", null, false, List.of("loan.product.manage"))));
        staff("mix1", "PRODUCT_APPROVER", "REPORT_VIEWER");
        rejects("SOD_CONFLICT", () -> roles.replacePermissions("REPORT_VIEWER", new ReplacePermissionsRequest(List.of("loan.account.read", "loan.product.manage"))),
                "granting a role a permission that breaks a current holder's separation of duties is refused");
        rejects("SOD_CONFLICT", () -> userService.assignRoles(row("mix1").id(), new AssignRolesRequest(List.of(new RoleGrantRequest("PRODUCT_APPROVER", null, null), new RoleGrantRequest("PROD_EDIT", null, null))), "bootstrap"), "and so is assigning it");
        T(() -> roles.update("REPORT_VIEWER", new UpdateRoleRequest("Report viewer", "reads", false, "RETIRED")));
        rejects("ROLE_RETIRED", () -> userService.assignRoles(row("rv1").id(), new AssignRolesRequest(List.of(new RoleGrantRequest("REPORT_VIEWER", null, null))), "bootstrap"), "a retired role cannot be assigned");

        // SoD rules
        rejects("RULE_EXISTS", () -> roles.addSodRule(new CreateSodRuleRequest("loan.product.manage", "loan.product.approve", "dup")), "an existing rule (either order) is refused");
        rejects("SOD_CONFLICT", () -> roles.addSodRule(new CreateSodRuleRequest("loan.product.read", "loan.account.read", "everyone holds both")), "a rule that current holders already break is refused");
        SodRuleView rule = T(() -> roles.addSodRule(new CreateSodRuleRequest("lcm.collateral.create", "loan.account.disburse", "test rule")));
        T(() -> { roles.deleteSodRule(rule.id()); return null; });

        // lifecycle
        long lo1 = row("lo1").id();
        T(() -> userService.suspend(lo1, "bootstrap"));
        eq("SUSPENDED", row("lo1").status(), "suspended");
        check(person0("lo1").isEmpty(), "a suspended user has no permissions");
        Authenticator.Result r = login("lo1", PW, null);
        eq(Authenticator.Outcome.FAILED, r.outcome(), "a suspended user cannot sign in");
        eq(1L, audits("LOGIN_FAILED", "lo1", "FAILURE"), "the refusal is audited with its reason");
        rejects("INVALID_STATE", () -> userService.suspend(lo1, "bootstrap"), "cannot suspend twice");
        T(() -> userService.reinstate(lo1));
        eq("ACTIVE", row("lo1").status(), "reinstated");
        T(() -> userService.expirePassword(lo1));
        eq(Authenticator.Outcome.PASSWORD_CHANGE_REQUIRED, login("lo1", PW, null).outcome(), "expired password forces a change");
        Tx.runKeeping(IamException.class, () -> { credentials.changeOwnPassword("lo1", PW, PW2); return null; });
        eq(Authenticator.Outcome.SUCCESS, login("lo1", PW2, null).outcome(), "new password works");
        eq(Authenticator.Outcome.FAILED, login("lo1", PW, null).outcome(), "old password does not");
        try { Tx.runKeeping(IamException.class, () -> { credentials.changeOwnPassword("lo1", PW2, PW); return null; }); check(false, "reuse must be refused"); }
        catch (IamException e) { eq("PASSWORD_POLICY", e.code(), "a recent password cannot be reused"); }
        try { Tx.runKeeping(IamException.class, () -> { credentials.changeOwnPassword("lo1", PW2, "short"); return null; }); check(false, "weak must be refused"); }
        catch (IamException e) { eq("PASSWORD_POLICY", e.code(), "a weak password is refused"); check(e.details() != null && !e.details().isEmpty(), "the broken rules are listed"); }
        try { Tx.runKeeping(IamException.class, () -> { credentials.changeOwnPassword("lo1", PW2, PW2); return null; }); check(false, "same must be refused"); }
        catch (IamException e) { eq("PASSWORD_POLICY", e.code(), "the same password is refused"); }
        UserRow lo = row("lo1");
        check(lo.passwordHash() != null, "password present");

        // reset password gives a new temporary password; the old one stops working
        SecretView sv = T(() -> userService.resetPassword(lo1, "bootstrap"));
        eq("TEMPORARY_PASSWORD", sv.secretKind(), "reset issues a temporary password");
        eq(Authenticator.Outcome.FAILED, login("lo1", PW2, null).outcome(), "the old password stops working at reset");
        eq(Authenticator.Outcome.PASSWORD_CHANGE_REQUIRED, login("lo1", sv.secret(), null).outcome(), "the temporary password leads to the change page");
        advance(Duration.ofHours(25));   // past tempPasswordHours
        eq(Authenticator.Outcome.FAILED, login("lo1", sv.secret(), null).outcome(), "an expired temporary password is refused");
        eq(1L, detailCount("LOGIN_FAILED", "lo1", "TEMP_PASSWORD_EXPIRED"), "and the reason is audited");
        SecretView sv2 = T(() -> userService.resetPassword(lo1, "bootstrap"));
        Tx.runKeeping(IamException.class, () -> { credentials.changeOwnPassword("lo1", sv2.secret(), PW3); return null; });
        eq(Authenticator.Outcome.SUCCESS, login("lo1", PW3, null).outcome(), "back in with a chosen password");

        // offboarding a user whose role was scheduled to start next week (regression: valid_to may not precede valid_from)
        staff("fut1");
        java.time.LocalDate nextWeek = java.time.LocalDate.ofInstant(now(), java.time.ZoneOffset.UTC).plusDays(7);
        T(() -> userService.assignRoles(row("fut1").id(), new AssignRolesRequest(List.of(new RoleGrantRequest("LOAN_OFFICER", nextWeek, null))), "bootstrap"));
        T(() -> userService.offboard(row("fut1").id(), "bootstrap"));
        eq("OFFBOARDED", row("fut1").status(), "a user with a future-dated role can be offboarded");

        // offboarding
        staff("gone1", "LOAN_OFFICER");
        long g = row("gone1").id();
        T(() -> userService.offboard(g, "bootstrap"));
        eq("OFFBOARDED", row("gone1").status(), "offboarded");
        eq(0L, count("SELECT count(*) FROM user_role WHERE user_id = ? AND ended_at IS NULL", g), "offboarding ends every role");
        rejects("INVALID_STATE", () -> userService.assignRoles(g, new AssignRolesRequest(List.of(new RoleGrantRequest("LOAN_OFFICER", null, null))), "bootstrap"), "an offboarded user gets no roles");
        rejects("USERNAME_TAKEN", () -> userService.create(new CreateUserRequest("gone1", "STAFF", "again", "g@x.test", null, null), "bootstrap"), "an offboarded username is never reused");
        check(userService.search("STAFF", null, "gone", 0, 10).total() == 1, "search by text finds the user");
    }

    static Set<String> person0(String u) { return T(() -> access.forUser(u).orElseThrow()).permissions(); }

    static void signIn() {
        section("sign-in");
        Authenticator.Result r = login("nobody.here", PW, null);
        eq(Authenticator.Outcome.FAILED, r.outcome(), "unknown user fails");
        eq(1L, audits("LOGIN_FAILED", "nobody.here"), "unknown user is audited");
        check(count("SELECT count(*) FROM audit_log WHERE action = 'LOGIN_FAILED' AND target_id = 'nobody.here' AND actor_type = 'ANONYMOUS'") == 1, "as an anonymous actor");
        eq(Authenticator.Outcome.FAILED, login("pm1", "wrong", null).outcome(), "wrong password fails");
        eq(1, row("pm1").failedAttempts(), "failure counted");
        eq(Authenticator.Outcome.SUCCESS, login("pm1", PW, null).outcome(), "right password succeeds");
        eq(0, row("pm1").failedAttempts(), "success clears the counter");
        check(row("pm1").lastLoginAt() != null, "last login stamped");
        eq(Authenticator.Outcome.SUCCESS, login(" pm1 ", PW, null).outcome(), "a username with spaces around it is trimmed");
        eq(Authenticator.Outcome.SUCCESS, login("PM1", PW, null).outcome(), "usernames are case-insensitive");
        eq(Authenticator.Outcome.FAILED, login("", PW, null).outcome(), "empty username fails");
        eq(Authenticator.Outcome.FAILED, login("pm1", null, null).outcome(), "null password fails");
        // verifyPasswordOnly shares the counters
        int before1 = row("pm1").failedAttempts();
        Authenticator.Result v = T(() -> authenticator.verifyPasswordOnly("pm1", "wrong-password"));
        eq(Authenticator.Outcome.FAILED, v.outcome(), "password-only check fails on a bad password");
        eq(before1 + 1, row("pm1").failedAttempts(), "and counts the failure");
        eq(Authenticator.Outcome.SUCCESS, T(() -> authenticator.verifyPasswordOnly("pm1", PW)).outcome(), "password-only check succeeds");
        eq(0, row("pm1").failedAttempts(), "and clears");
    }

    static void lockout() {
        section("lockout");
        for (int i = 1; i <= 4; i++) login("lcmm1", "bad" + i, null);
        eq(4, row("lcmm1").failedAttempts(), "four failures counted (they survive the refusal)");
        eq("ACTIVE", row("lcmm1").status(), "not yet locked");
        login("lcmm1", "bad5", null);
        eq("LOCKED", row("lcmm1").status(), "the fifth failure locks");
        check(row("lcmm1").lockedUntil() != null, "locked until is set");
        eq(1L, audits("USER_LOCKED", "lcmm1"), "the lock is audited");
        eq(Authenticator.Outcome.FAILED, login("lcmm1", PW, null).outcome(), "the right password is refused while locked");
        eq(5, row("lcmm1").failedAttempts(), "and does not count again");
        advance(Duration.ofMinutes(14));
        eq(Authenticator.Outcome.FAILED, login("lcmm1", PW, null).outcome(), "still locked at 14 minutes");
        advance(Duration.ofMinutes(2));
        eq(Authenticator.Outcome.SUCCESS, login("lcmm1", PW, null).outcome(), "unlocks by itself after 15 minutes");
        eq("ACTIVE", row("lcmm1").status(), "active again");
        eq(0, row("lcmm1").failedAttempts(), "counter cleared");
        // administrator unlock
        for (int i = 0; i < 5; i++) login("rv1", "bad", null);
        eq("LOCKED", row("rv1").status(), "second user locked");
        T(() -> userService.unlock(row("rv1").id()));
        eq("ACTIVE", row("rv1").status(), "unlocked by an administrator");
        eq(Authenticator.Outcome.SUCCESS, login("rv1", PW, null).outcome(), "and can sign in");
        rejects("INVALID_STATE", () -> userService.unlock(row("rv1").id()), "unlocking someone who is not locked is refused");
        // a lock for a person in the middle of a password change counts too
        for (int i = 0; i < 4; i++) {
            try { Tx.runKeeping(IamException.class, () -> { credentials.changeOwnPassword("au1", "wrong", PW2); return null; }); } catch (IamException e) { eq("INVALID_CREDENTIALS", e.code(), "bad current password on the change page"); }
        }
        eq(4, row("au1").failedAttempts(), "failures on the change-password page are counted and kept");
        eq(Authenticator.Outcome.SUCCESS, login("au1", PW, null).outcome(), "a good sign-in clears them");
    }

    static void secondFactor() {
        section("second factor");
        // pa1 holds an MFA-required role, so must enrol
        eq(Authenticator.Outcome.MFA_ENROLMENT_REQUIRED, login("pa1", PW, null).outcome(), "an MFA-required role demands enrolment");
        check(person0("pa1").isEmpty(), "and grants nothing yet");
        rejects("MFA_NOT_STARTED", () -> mfa.confirm("pa1", "123456"), "confirm before enrol");
        Enr e = enrolNow("pa1");
        eq(1L, audits("MFA_ENROLLED", "pa1"), "enrolment audited");
        eq(true, row("pa1").mfaEnabled(), "mfa on");
        check(row("pa1").mfaSecretEnc() != null && !row("pa1").mfaSecretEnc().contains(e.secret), "the secret is stored encrypted");
        check(row("pa1").mfaPendingEnc() == null, "pending secret cleared");
        check(!person0("pa1").isEmpty(), "permissions are live");
        eq((long) e.recovery.size(), count("SELECT count(*) FROM mfa_recovery_code WHERE user_id = ? AND used_at IS NULL", row("pa1").id()), "all recovery codes stored unused");
        check(count("SELECT count(*) FROM mfa_recovery_code WHERE user_id = ? AND position(? in code_hash) > 0", row("pa1").id(), e.recovery.get(0)) == 0, "recovery codes are stored hashed");
        rejects("MFA_ALREADY_ENABLED", () -> mfa.enrol("pa1"), "cannot enrol twice");

        advance(Duration.ofSeconds(35));
        eq(Authenticator.Outcome.FAILED, login("pa1", PW, null).outcome(), "password alone is not enough once MFA is on");
        eq(Authenticator.Outcome.FAILED, login("pa1", PW, "000000").outcome(), "wrong code fails");
        eq(2, row("pa1").failedAttempts(), "wrong and missing code both counted");
        Authenticator.Result r = login("pa1", PW, otp(e.secret));
        eq(Authenticator.Outcome.SUCCESS, r.outcome(), "correct code succeeds");
        check(r.mfaAt() != null, "mfa_at present");
        eq(Authenticator.Outcome.FAILED, login("pa1", PW, otp(e.secret)).outcome(), "the same code cannot be used twice (replay)");
        check(detailCount("MFA_FAILED", "pa1", "MFA_CODE_REPLAYED") == 1, "replay is audited as such");
        // drift: a code from the previous step is accepted if later than the last used step; the next step's too
        advance(Duration.ofSeconds(65));
        String nextCode = totp.code(e.secret, totp.stepAt(now()) + 1);
        eq(Authenticator.Outcome.SUCCESS, login("pa1", PW, nextCode).outcome(), "one step of drift ahead is accepted");
        String twoAhead = totp.code(e.secret, totp.stepAt(now()) + 3);
        eq(Authenticator.Outcome.FAILED, login("pa1", PW, twoAhead).outcome(), "three steps ahead is not");
        // recovery code
        String rc = e.recovery.get(0);
        eq(Authenticator.Outcome.SUCCESS, login("pa1", PW, rc).outcome(), "a recovery code works");
        eq(Authenticator.Outcome.FAILED, login("pa1", PW, rc).outcome(), "once");
        eq((long) e.recovery.size() - 1, count("SELECT count(*) FROM mfa_recovery_code WHERE user_id = ? AND used_at IS NULL", row("pa1").id()), "one recovery code spent");
        eq(1L, audits("MFA_RECOVERY_CODE_USED", "pa1"), "and audited");
        // concurrent use of one recovery code: exactly one wins
        String rc2 = e.recovery.get(1);
        int[] wins = new int[1];
        runParallel(4, i -> {
            Authenticator.Result x = login("pa1", PW, rc2);
            if (x.outcome() == Authenticator.Outcome.SUCCESS) synchronized (wins) { wins[0]++; }
        });
        eq(1, wins[0], "four simultaneous sign-ins with one recovery code: one wins");
        // a role requires MFA, so it cannot be turned off
        advance(Duration.ofSeconds(35));
        try { Tx.runKeeping(IamException.class, () -> { mfa.disable("pa1", otp(e.secret)); return null; }); check(false, "disable must be refused"); }
        catch (IamException ex) { eq("MFA_REQUIRED_BY_ROLE", ex.code(), "cannot turn off MFA while a role needs it"); }
        // someone without an MFA role may turn it off and on again
        staff("opt1", "AUDITOR");
        Enr o = enrolNow("opt1");
        advance(Duration.ofSeconds(35));
        Tx.runKeeping(IamException.class, () -> { mfa.disable("opt1", otp(o.secret)); return null; });
        eq(false, row("opt1").mfaEnabled(), "MFA turned off with a valid code");
        eq(0L, count("SELECT count(*) FROM mfa_recovery_code WHERE user_id = ? AND used_at IS NULL", row("opt1").id()), "recovery codes removed with it");
        // admin reset
        Enr p = enrolNow("pa2");
        T(() -> userService.resetMfa(row("pa2").id(), "bootstrap"));
        eq(false, row("pa2").mfaEnabled(), "an administrator can reset MFA");
        eq(1L, audits("MFA_RESET", "pa2"), "and it is audited");
        // MFA-required roles need MFA again after a reset
        check(person0("pa2").isEmpty(), "permissions of an MFA role are off again after the reset");
    }

    static class Enr {
        final String secret; final List<String> recovery;
        Enr(String secret, List<String> recovery) { this.secret = secret; this.recovery = recovery; }
    }

    static final Map<String, Enr> ENROLLED = new HashMap<>();

    static Enr enrolNow(String user) {
        List<String> r = enrolMfa(user);
        Enr e = new Enr(r.get(0), r.subList(1, r.size()));
        ENROLLED.put(user, e);
        return e;
    }

    /** Runs the body on n threads at once, each with its own database connection, and waits. */
    static void runParallel(int n, java.util.function.IntConsumer body) {
        Thread[] ts = new Thread[n];
        java.util.concurrent.CyclicBarrier gate = new java.util.concurrent.CyclicBarrier(n);
        for (int i = 0; i < n; i++) {
            final int k = i;
            ts[i] = new Thread(() -> {
                try { RequestContext.set(new RequestContext("corr-par-" + k, "10.0.0.9").as("SYSTEM", "parallel")); gate.await(); body.accept(k); }
                catch (Exception e) { throw new RuntimeException(e); }
                finally { jdbc.closeThread(); }
            });
            ts[i].start();
        }
        for (Thread t : ts) { try { t.join(); } catch (InterruptedException e) { Thread.currentThread().interrupt(); } }
    }

    /** Run last: it moves the clock 91 days, which ages every password. */
    static void passwordAge() {
        section("password age");
        // a password that is too old forces a change
        advance(Duration.ofDays(91));
        eq(Authenticator.Outcome.PASSWORD_CHANGE_REQUIRED, login("pm1", PW, null).outcome(), "a password past its age must be changed");
        eq("EXPIRED", row("pm1").status(), "and the user shows as EXPIRED");
        Tx.runKeeping(IamException.class, () -> { credentials.changeOwnPassword("pm1", PW, PW2); return null; });
        eq("ACTIVE", row("pm1").status(), "changing it restores ACTIVE");
        eq(Authenticator.Outcome.SUCCESS, login("pm1", PW2, null).outcome(), "sign in again");
    }
}
