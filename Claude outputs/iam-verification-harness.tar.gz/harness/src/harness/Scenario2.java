package harness;

import com.bank.lending.iam.access.AuthzService;
import com.bank.lending.iam.access.RoleDtos.*;
import com.bank.lending.iam.approval.ApprovalDtos.*;
import com.bank.lending.iam.client.ClientDtos.*;
import com.bank.lending.iam.common.*;
import com.bank.lending.iam.domain.AuthzDecisionEngine;
import com.bank.lending.iam.user.UserDtos.*;

import java.math.BigDecimal;
import java.time.Duration;
import java.util.*;
import java.util.concurrent.atomic.AtomicInteger;

import static harness.IamPgRun.*;

/** Service accounts, the authorization decision, and maker-checker approvals (with concurrency). */
public class Scenario2 {
    static final String P1 = "{\"productCode\":\"HL01\",\"rate\":\"8.5\"}";

    static void run() {
        clients();
        authz();
        approvalsBasic();
        approvalsLifecycle();
        approvalsTwoEyes();
        approvalsConcurrency();
    }

    // ------------------------------------------------------------------ clients
    static void clients() {
        section("service accounts and clients");
        CreatedClient c = T(() -> IamPgRun.clients.create(new CreateClientRequest("lcm-svc", "LCM service", "CONFIDENTIAL", List.of("client_credentials"), null, null, List.of("SVC_LCM"), null, null), "bootstrap"));
        check(c.secret() != null && c.secret().length() >= 32, "a secret is returned once");
        eq("ACTIVE", c.client().status(), "client active");
        eq(List.of("SVC_LCM"), c.client().roles(), "role attached");
        check(!c.client().grantTypes().contains("refresh_token"), "service accounts get no refresh token");
        String hash = jdbc.queryForObject("SELECT secret_hash FROM oauth_client WHERE client_id = 'lcm-svc'", String.class);
        check(hash != null && !hash.contains(c.secret()), "the secret is stored hashed");
        lcmSecret = c.secret();
        T(() -> IamPgRun.clients.create(new CreateClientRequest("batch-svc", "Batch", "CONFIDENTIAL", List.of("client_credentials"), null, null, List.of("SVC_BATCH"), 300, null), "bootstrap"));

        rejects("CLIENT_EXISTS", () -> IamPgRun.clients.create(new CreateClientRequest("lcm-svc", "dup", "CONFIDENTIAL", List.of("client_credentials"), null, null, null, null, null), "bootstrap"), "client ids are unique");
        rejects("VALIDATION_FAILED", () -> IamPgRun.clients.create(new CreateClientRequest("Bad Id", "x", "CONFIDENTIAL", List.of("client_credentials"), null, null, null, null, null), "bootstrap"), "client id format");
        rejects("VALIDATION_FAILED", () -> IamPgRun.clients.create(new CreateClientRequest("both-1", "x", "CONFIDENTIAL", List.of("client_credentials", "authorization_code"), List.of("https://a.example.com/cb"), null, null, null, null), "bootstrap"), "service and interactive do not mix");
        rejects("PUBLIC_CLIENT_NO_CC", () -> IamPgRun.clients.create(new CreateClientRequest("pub-cc", "x", "PUBLIC", List.of("client_credentials"), null, null, null, null, null), "bootstrap"), "a public client cannot use client credentials");
        rejects("REDIRECT_REQUIRED", () -> IamPgRun.clients.create(new CreateClientRequest("web-1", "x", "PUBLIC", List.of("authorization_code"), null, null, null, null, null), "bootstrap"), "interactive client needs a redirect");
        rejects("REDIRECT_NOT_ALLOWED", () -> IamPgRun.clients.create(new CreateClientRequest("web-2", "x", "PUBLIC", List.of("authorization_code"), List.of("http://evil.example.com/cb"), null, null, null, null), "bootstrap"), "plain http redirect to a remote host");
        rejects("REDIRECT_NOT_ALLOWED", () -> IamPgRun.clients.create(new CreateClientRequest("web-3", "x", "PUBLIC", List.of("authorization_code"), List.of("https://*.example.com/cb"), null, null, null, null), "bootstrap"), "wildcard redirect");
        rejects("REDIRECT_NOT_ALLOWED", () -> IamPgRun.clients.create(new CreateClientRequest("web-4", "x", "PUBLIC", List.of("authorization_code"), List.of("https://a.example.com/cb#frag"), null, null, null, null), "bootstrap"), "fragment in redirect");
        rejects("ROLE_KIND_MISMATCH", () -> IamPgRun.clients.create(new CreateClientRequest("svc-bad", "x", "CONFIDENTIAL", List.of("client_credentials"), null, null, List.of("AUDITOR"), null, null), "bootstrap"), "a staff role on a service account");
        eq(0L, count("SELECT count(*) FROM oauth_client WHERE client_id IN ('svc-bad','web-1','web-2','web-3','web-4','both-1','pub-cc')"), "refused clients leave nothing behind");
        eq(0L, count("SELECT count(*) FROM oauth_client_role WHERE client_id = 'svc-bad'"), "nor roles");

        CreatedClient pub = T(() -> IamPgRun.clients.create(new CreateClientRequest("admin-console", "Admin console", "PUBLIC", List.of("authorization_code"),
                List.of("https://admin.example.com/cb", "http://localhost:5173/cb"), List.of("https://admin.example.com/"), null, null, null), "bootstrap"));
        check(pub.secret() == null, "a public client has no secret");
        check(pub.client().grantTypes().contains("refresh_token"), "interactive clients get refresh tokens");
        rejects("NO_SECRET", () -> IamPgRun.clients.rotateSecret("admin-console"), "a public client has no secret to rotate");
        rejects("NOT_A_SERVICE_ACCOUNT", () -> IamPgRun.clients.replaceRoles("admin-console", new ReplaceClientRolesRequest(List.of("SVC_LCM"))), "roles are for service accounts");
        rejects("VALIDATION_FAILED", () -> IamPgRun.clients.update("admin-console", new UpdateClientRequest("x", null, null, 5, null)), "token lifetime out of range");

        RotatedSecret rs = T(() -> IamPgRun.clients.rotateSecret("lcm-svc"));
        check(!rs.secret().equals(lcmSecret), "rotation gives a new secret");
        check(rs.previousSecretValidUntil().isAfter(now()), "the old secret stays valid for a grace period");
        String prev = jdbc.queryForObject("SELECT previous_secret_hash FROM oauth_client WHERE client_id = 'lcm-svc'", String.class);
        check(prev != null, "the previous hash is kept during grace");
        check(hasher.matches(rs.secret(), jdbc.queryForObject("SELECT secret_hash FROM oauth_client WHERE client_id = 'lcm-svc'", String.class)), "the new secret matches");
        check(hasher.matches(lcmSecret, prev), "the old secret matches the previous hash");
        lcmSecret = rs.secret();

        // disable: no access, authorizations removed
        R(() -> jdbc.update("INSERT INTO oauth2_authorization (id, registered_client_id, principal_name, authorization_grant_type, access_token_value, access_token_expires_at) VALUES (?,?,?,?,?,?)",
                "auth-1", "lcm-svc", "lcm-svc", "client_credentials", "tok", "2099-01-01 00:00:00"));
        R(() -> jdbc.update("INSERT INTO oauth2_authorization (id, registered_client_id, principal_name, authorization_grant_type, access_token_value, access_token_expires_at) VALUES (?,?,?,?,?,?)",
                "auth-2", "batch-svc", "batch-svc", "client_credentials", "tok", "2099-01-01 00:00:00"));
        T(() -> IamPgRun.clients.disable("lcm-svc"));
        eq(0L, count("SELECT count(*) FROM oauth2_authorization WHERE registered_client_id = 'lcm-svc'"), "disabling removes the client's authorizations");
        eq(1L, count("SELECT count(*) FROM oauth2_authorization WHERE registered_client_id = 'batch-svc'"), "and nobody else's");
        check(!T(() -> access.forClient("lcm-svc").orElseThrow()).active(), "a disabled client is inactive");
        check(T(() -> access.forClient("lcm-svc").orElseThrow()).permissions().isEmpty(), "and holds no permissions");
        rejects("INVALID_STATE", () -> IamPgRun.clients.disable("lcm-svc"), "disable twice");
        T(() -> IamPgRun.clients.enable("lcm-svc"));
        check(T(() -> access.forClient("lcm-svc").orElseThrow()).active(), "enabled again");

        // a person's suspension removes their authorizations too
        R(() -> jdbc.update("INSERT INTO oauth2_authorization (id, registered_client_id, principal_name, authorization_grant_type, access_token_value, access_token_expires_at) VALUES (?,?,?,?,?,?)",
                "auth-3", "admin-console", "lo1", "authorization_code", "tok", "2099-01-01 00:00:00"));
        T(() -> userService.suspend(row("lo1").id(), "bootstrap"));
        eq(0L, count("SELECT count(*) FROM oauth2_authorization WHERE principal_name = 'lo1'"), "suspending a person removes their authorizations");
        check(row("lo1").tokensValidAfter() != null, "and sets the cut-off for tokens already issued");
        T(() -> userService.reinstate(row("lo1").id()));
    }

    static String lcmSecret;

    // ------------------------------------------------------------------ authz
    static AuthzDecisionEngine.Decision ask(Caller who, String subject, String permission, String branch, String product, String currency, String amount, java.time.Instant mfaAt) {
        return T(() -> authz.check(who, new AuthzService.CheckRequest(permission, subject, branch, product, currency, amount == null ? null : new BigDecimal(amount), null, null, mfaAt)));
    }

    static void authz() {
        section("authorization decisions");
        Caller lcm = service("lcm-svc");
        Caller batch = service("batch-svc");
        // grants
        eq("OK", ask(lcm, "lcmm1", "lcm.facility.create", null, null, null, null, null).code(), "granted permission is allowed");
        eq("NOT_GRANTED", ask(lcm, "lcmm1", "loan.account.disburse", null, null, null, null, null).code(), "ungranted permission is refused");
        eq("USER_NOT_ACTIVE", ask(lcm, "no.such.person", "lcm.facility.create", null, null, null, null, null).code(), "unknown subject looks like an inactive one");
        T(() -> userService.suspend(row("lo1").id(), "bootstrap"));
        eq("USER_NOT_ACTIVE", ask(lcm, "lo1", "loan.account.create", null, null, null, null, null).code(), "suspended subject");
        T(() -> userService.reinstate(row("lo1").id()));
        eq("OK", ask(lcm, "lo1", "loan.account.create", null, null, null, null, null).code(), "reinstated subject");
        try { ask(lcm, "lcmm1", "no.such.perm", null, null, null, null, null); check(false, "unknown permission must be refused"); }
        catch (IamException e) { eq("UNKNOWN_PERMISSION", e.code(), "unknown permission code is a caller error"); }
        try { ask(lcm, "lcmm1", " ", null, null, null, null, null); check(false, "blank permission must be refused"); }
        catch (IamException e) { eq("PERMISSION_REQUIRED", e.code(), "blank permission"); }

        // who may ask about someone else
        try { ask(batch, "lcmm1", "lcm.facility.create", null, null, null, null, null); check(false, "service without iam.authz.check"); }
        catch (IamException e) { eq("FORBIDDEN", e.code(), "a service without iam.authz.check may not ask about others"); }
        Caller lcmmCaller = person("lcmm1", false);
        try { ask(lcmmCaller, "lo1", "loan.account.create", null, null, null, null, null); check(false, "person asking about another"); }
        catch (IamException e) { eq("FORBIDDEN", e.code(), "a person may not ask about another subject"); }
        eq("OK", ask(lcmmCaller, null, "lcm.facility.create", null, null, null, null, null).code(), "a person asks about themselves");
        eq("OK", ask(lcmmCaller, "LCMM1", "lcm.facility.create", null, null, null, null, null).code(), "their own name in another case is still themselves");

        // scopes
        T(() -> userService.assignScopes(row("lcmm1").id(), new AssignScopesRequest(List.of(new ScopeRequest("BRANCH", "B001"), new ScopeRequest("PRODUCT", "HL01"), new ScopeRequest("CURRENCY", "INR"))), "bootstrap"));
        eq("OK", ask(lcm, "lcmm1", "lcm.facility.create", "B001", "HL01", "INR", null, null).code(), "inside every scope");
        eq("SCOPE_BRANCH", ask(lcm, "lcmm1", "lcm.facility.create", "B002", "HL01", "INR", null, null).code(), "wrong branch");
        eq("SCOPE_PRODUCT", ask(lcm, "lcmm1", "lcm.facility.create", "B001", "PL02", "INR", null, null).code(), "wrong product");
        eq("SCOPE_CURRENCY", ask(lcm, "lcmm1", "lcm.facility.create", "B001", "HL01", "USD", null, null).code(), "wrong currency");
        eq("OK", ask(lcm, "lcmm1", "lcm.facility.create", null, null, null, null, null).code(), "a call that names no branch is not restricted by branch");
        T(() -> userService.assignScopes(row("lcmm1").id(), new AssignScopesRequest(List.of(new ScopeRequest("BRANCH", "*"))), "bootstrap"));
        eq("OK", ask(lcm, "lcmm1", "lcm.facility.create", "B777", null, null, null, null).code(), "star means every branch");
        T(() -> userService.assignScopes(row("lcmm1").id(), new AssignScopesRequest(List.of()), "bootstrap"));
        eq("OK", ask(lcm, "lcmm1", "lcm.facility.create", "B777", "X", "JPY", null, null).code(), "no scopes means unrestricted");

        // ceilings
        T(() -> roles.replaceLimits("LCM_MAKER", new ReplaceLimitsRequest(List.of(new LimitRequest("lcm.facility.create", "INR", new BigDecimal("1000000")), new LimitRequest("lcm.facility.create", "*", new BigDecimal("20000"))))));
        AuthzDecisionEngine.Decision d = ask(lcm, "lcmm1", "lcm.facility.create", null, null, "INR", "1500000", null);
        eq("AMOUNT_ABOVE_LIMIT", d.code(), "above the INR ceiling");
        eq(new BigDecimal("1000000"), d.limit(), "the limit is reported");
        eq("OK", ask(lcm, "lcmm1", "lcm.facility.create", null, null, "INR", "1000000", null).code(), "exactly at the ceiling");
        eq("AMOUNT_ABOVE_LIMIT", ask(lcm, "lcmm1", "lcm.facility.create", null, null, "USD", "25000", null).code(), "other currencies use the * row");
        eq("OK", ask(lcm, "lcmm1", "lcm.facility.create", null, null, "USD", "19999.99", null).code(), "under the * row");
        eq("OK", ask(lcm, "lcmm1", "lcm.facility.create", null, null, null, null, null).code(), "no amount, no ceiling check");
        // a second role without a ceiling lifts it
        T(() -> roles.create(new CreateRoleRequest("LCM_BIG", "LCM big", "STAFF", null, false, List.of("lcm.facility.create"))));
        T(() -> userService.assignRoles(row("lcmm1").id(), new AssignRolesRequest(List.of(new RoleGrantRequest("LCM_MAKER", null, null), new RoleGrantRequest("LCM_BIG", null, null))), "bootstrap"));
        eq("OK", ask(lcm, "lcmm1", "lcm.facility.create", null, null, "INR", "5000000", null).code(), "another role without a ceiling lifts the ceiling");
        T(() -> userService.assignRoles(row("lcmm1").id(), new AssignRolesRequest(List.of(new RoleGrantRequest("LCM_MAKER", null, null))), "bootstrap"));
        eq("AMOUNT_ABOVE_LIMIT", ask(lcm, "lcmm1", "lcm.facility.create", null, null, "INR", "5000000", null).code(), "and back again when the role is removed");
        // clearing the limits
        T(() -> roles.replaceLimits("LCM_MAKER", new ReplaceLimitsRequest(List.of())));
        eq("OK", ask(lcm, "lcmm1", "lcm.facility.create", null, null, "INR", "5000000", null).code(), "no limits, no ceiling");
        try { T(() -> roles.replaceLimits("LCM_MAKER", new ReplaceLimitsRequest(List.of(new LimitRequest("loan.account.disburse", "INR", BigDecimal.ONE))))); check(false, "limit for a permission the role lacks"); }
        catch (IamException e) { eq("PERMISSION_NOT_IN_ROLE", e.code(), "a limit needs a permission the role holds"); }

        // step-up
        long denials = audits("AUTHZ_DENIED", "loan.product.approve");
        d = ask(lcm, "pa1", "loan.product.approve", null, null, null, null, null);
        eq("STEP_UP_REQUIRED", d.code(), "an MFA permission without a recent second factor");
        check(d.stepUpRequired() && !d.allowed(), "reported as step-up, not allowed");
        eq("OK", ask(lcm, "pa1", "loan.product.approve", null, null, null, null, now()).code(), "with a fresh second factor");
        eq("STEP_UP_REQUIRED", ask(lcm, "pa1", "loan.product.approve", null, null, null, null, now().minus(Duration.ofMinutes(20))).code(), "a second factor older than the window");
        eq("OK", ask(lcm, "pa1", "loan.product.approve", null, null, null, null, now().minus(Duration.ofMinutes(10))).code(), "within the window");
        eq("STEP_UP_REQUIRED", ask(lcm, "pa1", "loan.product.approve", null, null, null, null, now().plus(Duration.ofMinutes(10))).code(), "a second factor dated in the future is not believed");
        eq(denials + 3, audits("AUTHZ_DENIED", "loan.product.approve"), "denials of high-risk permissions are audited");
        // a person's own check uses the token's mfa_at
        eq("OK", ask(person("pa1", true), null, "loan.product.approve", null, null, null, null, null).code(), "own check with mfa_at in the token");
        eq("STEP_UP_REQUIRED", ask(person("pa1", false), null, "loan.product.approve", null, null, null, null, null).code(), "own check without");
        eq("OK", ask(person("pa1", false), null, "loan.product.read", null, null, null, null, null).code(), "non-MFA permission needs no second factor");
        // grants end by date
        T(() -> userService.assignRoles(row("rv1").id(), new AssignRolesRequest(List.of(new RoleGrantRequest("AUDITOR", java.time.LocalDate.ofInstant(now(), java.time.ZoneOffset.UTC).plusDays(3), java.time.LocalDate.ofInstant(now(), java.time.ZoneOffset.UTC).plusDays(5)))), "bootstrap"));
        eq("NOT_GRANTED", ask(lcm, "rv1", "iam.audit.read", null, null, null, null, null).code(), "a role not yet started");
    }

    // ------------------------------------------------------------------ approvals
    static ActionView submit(String maker, String type, String target, String payload, String amount, String cur, String key) {
        return T(() -> approvals.submit(person(maker, false), new SubmitRequest(type, target, "Change " + target, payload, amount == null ? null : new BigDecimal(amount), cur, null, null, null), key));
    }

    static DecisionOutcome decide(String who, boolean mfa, String id, boolean approve, String comment) {
        Caller c = person(who, mfa);
        return Tx.runKeeping(IamException.class, () -> approvals.decide(c, id, approve, comment));
    }

    static void expectDecide(String code, String who, boolean mfa, String id, boolean approve, String comment, String msg) {
        try { decide(who, mfa, id, approve, comment); check(false, msg + " (expected " + code + " but it was accepted)"); }
        catch (IamException e) { eq(code, e.code(), msg); }
    }

    static void approvalsBasic() {
        section("approvals: submit and decide");
        enrolMfa("pa2");   // after the admin reset in the MFA scenario
        advance(Duration.ofSeconds(35));
        ActionView a = submit("pm1", "LOAN_PRODUCT_CHANGE", "HL01", P1, null, null, "k-1");
        eq("PENDING", a.status(), "submitted action is pending");
        eq("pm1", a.maker(), "maker recorded");
        eq(Hashing.sha256Hex(Json.canonical(P1)), a.payloadHash(), "payload hash is over the canonical JSON");
        eq(1L, audits("APPROVAL_SUBMITTED", a.id()), "submission audited");
        eq(1L, count("SELECT count(*) FROM event_outbox WHERE event_type = 'APPROVAL_SUBMITTED' AND subject_key = ?", "approval:" + a.id()), "and published");
        ActionView again = submit("pm1", "LOAN_PRODUCT_CHANGE", "HL01", P1, null, null, "k-1");
        eq(a.id(), again.id(), "the same Idempotency-Key returns the same action");
        ActionView other = submit("pm1", "LOAN_PRODUCT_CHANGE", "HL01", P1, null, null, "k-2");
        check(!other.id().equals(a.id()), "a different key makes another action");
        ActionView reordered = submit("pm1", "LOAN_PRODUCT_CHANGE", "HL01", "{ \"rate\" : \"8.5\", \"productCode\":\"HL01\" }", null, null, "k-3");
        eq(a.payloadHash(), reordered.payloadHash(), "key order and spacing do not change the hash");
        rejects("PAYLOAD_INVALID", () -> approvals.submit(person("pm1", false), new SubmitRequest("LOAN_PRODUCT_CHANGE", "HL01", "x", "not json", null, null, null, null, null), null), "payload must be JSON");
        rejects("NOT_FOUND", () -> approvals.submit(person("pm1", false), new SubmitRequest("NO_SUCH_TYPE", "HL01", "x", P1, null, null, null, null, null), null), "unknown type");
        rejects("NOT_A_MAKER", () -> approvals.submit(person("pa1", true), new SubmitRequest("LOAN_PRODUCT_CHANGE", "HL01", "x", P1, null, null, null, null, null), null), "a checker is not a maker");
        rejects("VALIDATION_FAILED", () -> approvals.submit(person("pm1", false), new SubmitRequest("LOAN_PRODUCT_CHANGE", "HL01", "x", P1, new BigDecimal("5"), null, null, null, null), null), "an amount needs a currency");

        // submit on behalf
        ActionView ob = T(() -> approvals.submit(service("lcm-svc"), new SubmitRequest("LCM_FACILITY_CHANGE", "FAC-1", "Raise limit", "{\"limit\":\"900000\"}", new BigDecimal("900000"), "INR", "B001", null, "lcmm1"), "ob-1"));
        eq("lcmm1", ob.maker(), "the user is the maker");
        eq("lcm-svc", ob.submittedBy(), "the service is recorded as the submitter");
        rejects("NOT_ALLOWED_ON_BEHALF", () -> approvals.submit(service("batch-svc"), new SubmitRequest("LCM_FACILITY_CHANGE", "FAC-2", "x", "{}", null, null, null, null, "lcmm1"), null), "a service without the on-behalf permission");
        rejects("NOT_ALLOWED_ON_BEHALF", () -> approvals.submit(person("pm1", false), new SubmitRequest("LOAN_PRODUCT_CHANGE", "HL01", "x", P1, null, null, null, null, "pm1"), null), "a person cannot submit on behalf");
        rejects("MAKER_UNKNOWN", () -> approvals.submit(service("lcm-svc"), new SubmitRequest("LCM_FACILITY_CHANGE", "FAC-3", "x", "{}", null, null, null, null, "ghost"), null), "unknown maker");
        rejects("NOT_A_MAKER", () -> approvals.submit(service("lcm-svc"), new SubmitRequest("LCM_FACILITY_CHANGE", "FAC-4", "x", "{}", null, null, null, null, "pm1"), null), "the named user is not a maker of this type");
        rejects("NOT_A_MAKER", () -> approvals.submit(service("lcm-svc"), new SubmitRequest("LCM_FACILITY_CHANGE", "FAC-5", "x", "{}", null, null, null, null, null), null), "the service itself is not a maker");

        // decisions
        expectDecide("MAKER_CANNOT_APPROVE", "pm1", true, a.id(), true, null, "the maker cannot approve");
        expectDecide("NOT_A_CHECKER", "lo1", true, a.id(), true, null, "someone without the checker permission");
        expectDecide("COMMENT_REQUIRED", "pa1", true, a.id(), false, null, "rejecting needs a comment");
        long denied = audits("APPROVAL_DECISION_DENIED", a.id());
        expectDecide("STEP_UP_REQUIRED", "pa1", false, a.id(), true, null, "approving without a fresh second factor");
        eq(denied + 1, audits("APPROVAL_DECISION_DENIED", a.id()), "the refusal is audited even though the call failed");
        eq("PENDING", T(() -> approvals.get(a.id())).status(), "and the action is untouched");
        DecisionOutcome o = decide("pa1", true, a.id(), true, "looks right");
        eq("APPROVED", o.action().status(), "approved");
        check(o.error() == null, "no error");
        check(o.action().consumeDeadline() != null && o.action().consumeDeadline().equals(now().plus(Duration.ofHours(24))), "consume deadline = now + 24h");
        eq(1, o.action().approvalsGiven(), "one approval");
        eq(1L, count("SELECT count(*) FROM event_outbox WHERE event_type = 'APPROVAL_APPROVED' AND subject_key = ?", "approval:" + a.id()), "approval event published");
        expectDecide("ACTION_NOT_PENDING", "pa2", true, a.id(), true, null, "an approved action cannot be decided again");
        // consume
        Caller lcmSvc = service("lcm-svc");
        rejects("ACTION_NOT_APPROVED", () -> approvals.consume(lcmSvc, other.id(), "R-0"), "a pending action cannot be consumed");
        ActionView cons = T(() -> approvals.consume(lcmSvc, a.id(), "REF-1"));
        eq("CONSUMED", cons.status(), "consumed");
        eq("lcm-svc", cons.consumedBy(), "by the service");
        ActionView cons2 = T(() -> approvals.consume(lcmSvc, a.id(), "REF-1"));
        eq("CONSUMED", cons2.status(), "the same consume again is answered with the first result");
        rejects("ALREADY_CONSUMED", () -> approvals.consume(lcmSvc, a.id(), "REF-2"), "another reference is a second use");
        eq(1L, audits("APPROVAL_CONSUMED", a.id()), "consumed once in the audit trail");
        // rejection
        DecisionOutcome rj = decide("pa1", true, other.id(), false, "rate is wrong");
        eq("REJECTED", rj.action().status(), "rejected");
        rejects("ACTION_NOT_APPROVED", () -> approvals.consume(lcmSvc, other.id(), "R-1"), "a rejected action cannot be consumed");
        // cancel
        ActionView cx = submit("pm1", "LOAN_PRODUCT_CHANGE", "HL02", P1, null, null, null);
        rejects("NOT_THE_MAKER", () -> approvals.cancel(person("lo1", false), cx.id()), "only the maker cancels");
        eq("CANCELLED", T(() -> approvals.cancel(person("pm1", false), cx.id())).status(), "the maker cancels a pending action");
        rejects("ACTION_NOT_PENDING", () -> approvals.cancel(person("pm1", false), cx.id()), "cancel twice");
        expectDecide("ACTION_NOT_PENDING", "pa1", true, cx.id(), true, null, "a cancelled action cannot be approved");
        rejects("NOT_FOUND", () -> approvals.get("00000000-0000-0000-0000-000000000000"), "unknown id");
        rejects("NOT_FOUND", () -> approvals.get("not-a-uuid"), "malformed id is treated as unknown");

        // ceilings on the checker
        T(() -> roles.replaceLimits("LCM_CHECKER", new ReplaceLimitsRequest(List.of(new LimitRequest("lcm.facility.approve", "INR", new BigDecimal("500000"))))));
        enrolMfa("lcmc1");
        advance(Duration.ofSeconds(35));
        expectDecide("AMOUNT_ABOVE_LIMIT", "lcmc1", true, ob.id(), true, null, "a checker cannot approve above their ceiling");
        T(() -> roles.replaceLimits("LCM_CHECKER", new ReplaceLimitsRequest(List.of())));
        T(() -> userService.assignScopes(row("lcmc1").id(), new AssignScopesRequest(List.of(new ScopeRequest("BRANCH", "B009"))), "bootstrap"));
        expectDecide("SCOPE_BRANCH", "lcmc1", true, ob.id(), true, null, "nor outside their branch scope");
        T(() -> userService.assignScopes(row("lcmc1").id(), new AssignScopesRequest(List.of(new ScopeRequest("BRANCH", "B001"))), "bootstrap"));
        eq("APPROVED", decide("lcmc1", true, ob.id(), true, null).action().status(), "inside scope and ceiling");

        // inbox
        ActionView inb = submit("pm1", "LOAN_PRODUCT_CHANGE", "HL03", P1, null, null, null);
        List<String> ids = T(() -> approvals.inbox(person("pa1", true))).stream().map(ActionView::id).toList();
        check(ids.contains(inb.id()), "the checker's inbox lists the pending action");
        check(!T(() -> approvals.inbox(person("pm1", false))).stream().anyMatch(x -> x.id().equals(inb.id())), "the maker's inbox does not");
        check(!T(() -> approvals.inbox(person("lcmc1", true))).stream().anyMatch(x -> x.id().equals(inb.id())), "a checker of another type does not see it");
        decide("pa1", true, inb.id(), false, "no");
        check(!T(() -> approvals.inbox(person("pa1", true))).stream().anyMatch(x -> x.id().equals(inb.id())), "a decided action leaves the inbox");
    }

    static void approvalsLifecycle() {
        section("approvals: expiry and offboarding");
        ActionView e1 = submit("pm1", "LOAN_PRODUCT_CHANGE", "EXP1", P1, null, null, null);
        ActionView e2 = submit("pm1", "LOAN_PRODUCT_CHANGE", "EXP2", P1, null, null, null);
        ActionView e3 = submit("pm1", "LOAN_PRODUCT_CHANGE", "EXP3", P1, null, null, null);
        decide("pa1", true, e3.id(), true, null);       // approved, never consumed
        advance(Duration.ofHours(25));                 // e3's consume window is over; e1/e2 still pending (72h)
        rejects("ACTION_EXPIRED", () -> approvals.consume(service("lcm-svc"), e3.id(), "late"), "an approval cannot be consumed after its deadline");
        long expiredBefore = count("SELECT count(*) FROM pending_action WHERE status = 'EXPIRED'");
        int swept1 = T(() -> approvals.expireDue());
        check(swept1 >= 1, "the sweep expires the approved-but-unused actions (" + swept1 + ")");
        eq(expiredBefore + swept1, count("SELECT count(*) FROM pending_action WHERE status = 'EXPIRED'"), "the count it reports is the count it changed");
        eq("EXPIRED", T(() -> approvals.get(e3.id())).status(), "e3 expired");
        eq(1L, count("SELECT count(*) FROM event_outbox WHERE event_type = 'APPROVAL_EXPIRED' AND subject_key = ?", "approval:" + e3.id()), "expiry published");
        eq(1L, audits("APPROVAL_EXPIRED", e3.id()), "and audited as the system");
        advance(Duration.ofHours(48));                 // e1/e2 now past their 72h
        DecisionOutcome late = decide("pa1", true, e1.id(), true, null);
        eq("ACTION_EXPIRED", late.error(), "a late decision is reported as ACTION_EXPIRED");
        eq("EXPIRED", late.action().status(), "and the action is recorded as expired (the change survives the failure report)");
        eq("EXPIRED", T(() -> approvals.get(e1.id())).status(), "persisted");
        int swept2 = T(() -> approvals.expireDue());
        check(swept2 >= 1, "the sweep expires the remaining pending ones (" + swept2 + ")");
        eq(0, T(() -> approvals.expireDue()), "and is idempotent");
        eq("EXPIRED", T(() -> approvals.get(e2.id())).status(), "e2 expired");
        expectDecide("ACTION_NOT_PENDING", "pa1", true, e2.id(), true, null, "an expired action cannot be decided");

        // offboarding a maker withdraws their pending actions
        staff("mk2", "PRODUCT_MANAGER");
        ActionView p = submit("mk2", "LOAN_PRODUCT_CHANGE", "OFF1", P1, null, null, null);
        ActionView p2 = submit("mk2", "LOAN_PRODUCT_CHANGE", "OFF2", P1, null, null, null);
        decide("pa1", true, p2.id(), true, null);
        T(() -> userService.offboard(row("mk2").id(), "bootstrap"));
        eq("CANCELLED", T(() -> approvals.get(p.id())).status(), "the pending action of an offboarded maker is cancelled");
        eq("APPROVED", T(() -> approvals.get(p2.id())).status(), "an already approved one is left for the consumer");
        eq(1L, count("SELECT count(*) FROM event_outbox WHERE event_type = 'APPROVAL_CANCELLED' AND subject_key = ?", "approval:" + p.id()), "cancellation published");
    }

    static void approvalsTwoEyes() {
        section("approvals: two approvers, types");
        TypeSaved t = T(() -> approvals.createType(new CreateTypeRequest("PRODUCT_RETIRE", "Retire product", "loan.product.manage", "loan.product.approve", 2, 48, 12, null)));
        eq(2, t.type().approvalsRequired(), "type created needing two approvals");
        rejects("TYPE_EXISTS", () -> approvals.createType(new CreateTypeRequest("PRODUCT_RETIRE", "dup", "loan.product.manage", "loan.product.approve", 1, null, null, null)), "type codes are unique");
        rejects("SAME_PERMISSION", () -> approvals.createType(new CreateTypeRequest("T_SAME", "x", "loan.product.manage", "loan.product.manage", 1, null, null, null)), "maker and checker permission differ");
        rejects("UNKNOWN_PERMISSION", () -> approvals.createType(new CreateTypeRequest("T_UNK", "x", "loan.product.manage", "no.such", 1, null, null, null)), "permissions come from the catalogue");
        rejects("VALIDATION_FAILED", () -> approvals.createType(new CreateTypeRequest("T_THREE", "x", "loan.product.manage", "loan.product.approve", 3, null, null, null)), "one or two approvals only");
        ActionView a = submit("pm1", "PRODUCT_RETIRE", "HL01", P1, null, null, null);
        eq(2, a.approvalsNeeded(), "the action needs two");
        DecisionOutcome o1 = decide("pa1", true, a.id(), true, "first");
        eq("PENDING", o1.action().status(), "still pending after one approval");
        eq(1, o1.action().approvalsGiven(), "one given");
        expectDecide("ALREADY_DECIDED", "pa1", true, a.id(), true, null, "the same person cannot approve twice");
        eq(0L, count("SELECT count(*) FROM event_outbox WHERE event_type = 'APPROVAL_APPROVED' AND subject_key = ?", "approval:" + a.id()), "no approval event until the last approval");
        DecisionOutcome o2 = decide("pa2", true, a.id(), true, "second");
        eq("APPROVED", o2.action().status(), "approved by the second");
        eq(2, o2.action().approvalsGiven(), "two given");
        eq(2, o2.action().decisions().size(), "both decisions listed");
        // a rejection after one approval ends it
        ActionView b = submit("pm1", "PRODUCT_RETIRE", "HL02", P1, null, null, null);
        decide("pa1", true, b.id(), true, null);
        eq("REJECTED", decide("pa2", true, b.id(), false, "no").action().status(), "one rejection is final");
        // update type
        TypeSaved u = T(() -> approvals.updateType("PRODUCT_RETIRE", new UpdateTypeRequest("Retire product", 1, 48, 12, "https://cb.example.com/approvals", true)));
        check(u.callbackSecret() != null, "a callback secret is shown when the callback is created");
        eq(1L, count("SELECT count(*) FROM webhook_subscription WHERE approval_type_code = 'PRODUCT_RETIRE'"), "the callback is a subscription owned by the type");
        TypeSaved u2 = T(() -> approvals.updateType("PRODUCT_RETIRE", new UpdateTypeRequest("Retire product", 1, 48, 12, "https://cb.example.com/approvals2", true)));
        check(u2.callbackSecret() == null, "the secret is not shown again");
        eq(1L, count("SELECT count(*) FROM webhook_subscription WHERE approval_type_code = 'PRODUCT_RETIRE'"), "still one subscription");
        T(() -> approvals.updateType("PRODUCT_RETIRE", new UpdateTypeRequest("Retire product", 1, 48, 12, null, false)));
        eq(0L, count("SELECT count(*) FROM webhook_subscription WHERE approval_type_code = 'PRODUCT_RETIRE' AND active"), "removing the callback deactivates the subscription");
        rejects("TYPE_INACTIVE", () -> approvals.submit(person("pm1", false), new SubmitRequest("PRODUCT_RETIRE", "HL01", "x", P1, null, null, null, null, null), null), "an inactive type takes no submissions");
        rejects("URL_NOT_ALLOWED", () -> approvals.updateType("PRODUCT_RETIRE", new UpdateTypeRequest("Retire product", 1, 48, 12, "http://insecure.example.com/cb", true)), "plain http callbacks are refused");
    }

    static void approvalsConcurrency() {
        section("approvals: concurrency");
        // 1. two checkers approve the same one-approval action at once: one wins, the other is told it is no longer pending
        ActionView a = submit("pm1", "LOAN_PRODUCT_CHANGE", "RACE1", P1, null, null, null);
        // PRODUCT_RETIRE is now inactive, use LOAN_PRODUCT_CHANGE (one approval)
        AtomicInteger ok = new AtomicInteger(), notPending = new AtomicInteger(), other = new AtomicInteger();
        String[] who = {"pa1", "pa2"};
        Scenario1.runParallel(2, i -> {
            try { decide(who[i], true, a.id(), true, null); ok.incrementAndGet(); }
            catch (IamException e) { if (e.code().equals("ACTION_NOT_PENDING")) notPending.incrementAndGet(); else { other.incrementAndGet(); System.out.println("    unexpected " + e.code()); } }
        });
        eq(1, ok.get(), "two simultaneous approvals: one succeeds");
        eq(1, notPending.get(), "the other is told the action is no longer pending");
        eq(1L, count("SELECT count(*) FROM approval_decision WHERE action_id = ?::uuid", a.id()), "only one decision row");
        eq(1L, count("SELECT count(*) FROM event_outbox WHERE event_type = 'APPROVAL_APPROVED' AND subject_key = ?", "approval:" + a.id()), "one approval event");

        // 2. four services consume the same approval with different references: one wins
        AtomicInteger won = new AtomicInteger(), lost = new AtomicInteger();
        Scenario1.runParallel(4, i -> {
            try { T(() -> approvals.consume(service("lcm-svc"), a.id(), "RACE-" + i)); won.incrementAndGet(); }
            catch (IamException e) { if (e.code().equals("ALREADY_CONSUMED")) lost.incrementAndGet(); else System.out.println("    unexpected " + e.code()); }
        });
        // (each call below runs in its own transaction on its own connection)
        eq(1, won.get(), "four simultaneous consumes with different references: one wins");
        eq(3, lost.get(), "the others get ALREADY_CONSUMED");
        eq(1L, audits("APPROVAL_CONSUMED", a.id()), "audited once");

        // 3. the same reference from four threads: all are answered, one consume happens
        ActionView b = submit("pm1", "LOAN_PRODUCT_CHANGE", "RACE2", P1, null, null, null);
        decide("pa1", true, b.id(), true, null);
        AtomicInteger answered = new AtomicInteger();
        Scenario1.runParallel(4, i -> {
            try { if ("CONSUMED".equals(T(() -> approvals.consume(service("lcm-svc"), b.id(), "SAME")).status())) answered.incrementAndGet(); }
            catch (IamException e) { System.out.println("    unexpected " + e.code()); }
        });
        eq(4, answered.get(), "four simultaneous consumes with the same reference are all answered");
        eq(1L, audits("APPROVAL_CONSUMED", b.id()), "and the action is consumed once");

        // 4. the same Idempotency-Key from four threads: one action, everyone gets it
        Set<String> seen = Collections.synchronizedSet(new TreeSet<>());
        AtomicInteger errors = new AtomicInteger();
        Scenario1.runParallel(4, i -> {
            try { seen.add(submit("pm1", "LOAN_PRODUCT_CHANGE", "RACE3", P1, null, null, "race-key").id()); }
            catch (RuntimeException e) { errors.incrementAndGet(); System.out.println("    submit failed: " + e.getClass().getSimpleName() + " " + e.getMessage()); }
        });
        eq(1L, count("SELECT count(*) FROM pending_action WHERE idempotency_key = 'race-key'"), "one action exists for one Idempotency-Key");
        eq(0, errors.get(), "no caller gets an error from the race");
        eq(1, seen.size(), "every caller is given the same action");

        // 5. forced race: another transaction holds an uncommitted row with the key when this submit inserts
        String forced = java.util.UUID.randomUUID().toString();
        jdbc.update("INSERT INTO pending_action (action_id, type_code, target_ref, summary, payload, payload_hash, status, maker, submitted_by, idempotency_key, approvals_needed, expires_at) "
                + "VALUES (?::uuid, 'LOAN_PRODUCT_CHANGE', 'FORCED', 'x', '{}', ?, 'PENDING', 'pm1', 'pm1', 'forced-key', 1, ?)", forced, Hashing.sha256Hex("{}"), now().plus(Duration.ofHours(5)).toString());
        String[] got = new String[1];
        Throwable[] failure = new Throwable[1];
        Thread t = new Thread(() -> {
            RequestContext.set(new RequestContext("corr-forced", "10.0.0.9").as("SYSTEM", "forced"));
            try { got[0] = submit("pm1", "LOAN_PRODUCT_CHANGE", "FORCED", P1, null, null, "forced-key").id(); }
            catch (Throwable e) { failure[0] = e; }
            finally { jdbc.closeThread(); }
        });
        t.start();
        try { Thread.sleep(700); } catch (InterruptedException e) { Thread.currentThread().interrupt(); }
        jdbc.tx("commit");
        try { t.join(); } catch (InterruptedException e) { Thread.currentThread().interrupt(); }
        check(failure[0] == null, "a submit that loses the insert race to an uncommitted twin still answers" + (failure[0] == null ? "" : " (got " + failure[0] + ")"));
        eq(forced, got[0], "and returns the twin's action");
        eq(1L, count("SELECT count(*) FROM pending_action WHERE idempotency_key = 'forced-key'"), "still one action");
    }
}
