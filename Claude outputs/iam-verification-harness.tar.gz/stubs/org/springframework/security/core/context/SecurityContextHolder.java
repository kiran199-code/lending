package org.springframework.security.core.context;
public class SecurityContextHolder { public static void setContext(SecurityContext c){} }
