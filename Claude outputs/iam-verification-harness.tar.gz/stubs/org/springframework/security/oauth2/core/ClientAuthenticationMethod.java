package org.springframework.security.oauth2.core;
public final class ClientAuthenticationMethod { public static final ClientAuthenticationMethod NONE=new ClientAuthenticationMethod(), CLIENT_SECRET_BASIC=new ClientAuthenticationMethod(), CLIENT_SECRET_POST=new ClientAuthenticationMethod(); }
