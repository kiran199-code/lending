package org.springframework.security.core;
public abstract class AuthenticationException extends RuntimeException { public AuthenticationException(String m){super(m);} }
