package org.springframework.security.core;
public interface Authentication extends java.security.Principal, java.io.Serializable {
  java.util.Collection<? extends GrantedAuthority> getAuthorities(); Object getCredentials(); Object getDetails(); Object getPrincipal(); boolean isAuthenticated();
}
