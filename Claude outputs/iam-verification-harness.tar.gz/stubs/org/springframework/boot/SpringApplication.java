package org.springframework.boot;
public class SpringApplication { public static void run(Class<?> c, String... a){} }
