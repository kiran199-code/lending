package org.springframework.security.oauth2.jose.jws;
public enum SignatureAlgorithm { RS256 }
