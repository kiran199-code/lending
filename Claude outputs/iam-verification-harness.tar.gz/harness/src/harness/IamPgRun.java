package harness;

import com.bank.lending.iam.access.*;
import com.bank.lending.iam.access.RoleDtos.*;
import com.bank.lending.iam.approval.*;
import com.bank.lending.iam.approval.ApprovalDtos.*;
import com.bank.lending.iam.audit.AuditService;
import com.bank.lending.iam.auth.*;
import com.bank.lending.iam.client.*;
import com.bank.lending.iam.client.ClientDtos.*;
import com.bank.lending.iam.common.*;
import com.bank.lending.iam.config.IamSettings;
import com.bank.lending.iam.crypto.SecretCrypto;
import com.bank.lending.iam.customer.*;
import com.bank.lending.iam.customer.CustomerDtos.*;
import com.bank.lending.iam.domain.*;
import com.bank.lending.iam.events.*;
import com.bank.lending.iam.keys.*;
import com.bank.lending.iam.user.*;
import com.bank.lending.iam.user.UserDtos.*;

import java.math.BigDecimal;
import java.time.*;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.function.Supplier;

/** Runs the real IAM services and repositories against a real PostgreSQL 16 (schema iam, throwaway database iamtest). */
public class IamPgRun {
    static PgJdbc jdbc;
    static MutableClock clock;
    static IamSettings settings;
    static SecretCrypto crypto, crypto2;
    static SecretHasher hasher;
    static TotpService totp = new TotpService();

    static UserRepository userRepo; static RbacRepository rbacRepo; static ClientRepository clientRepo; static CustomerRepository customerRepo;
    static EventRepository eventRepo; static ApprovalRepository approvalRepo; static KeyRepository keyRepo;
    static AuditService audit; static EventService events; static ConsentService consents; static Authenticator authenticator;
    static RevocationService revocation; static CredentialService credentials; static MfaService mfa; static AccessService access; static AuthzService authz;
    static WebhookService webhooks; static ApprovalService approvals; static UserService userService; static SelfService selfService;
    static RoleService roles; static ClientService clients; static KeyService keys; static CustomerService customers; static BootstrapService bootstrap;
    static WebhookDispatcher dispatcher; static SweepService sweep; static ReencryptService reencrypt;
    static FakeSender sender = new FakeSender();

    static int checks = 0, failures = 0;

    static class FakeSender implements HttpSender {
        final List<String[]> sent = Collections.synchronizedList(new ArrayList<>());   // url, body, signature
        volatile int status = 200;
        volatile String failUrlContaining = null;
        public Response post(String url, String body, Map<String, String> headers, Duration timeout) {
            sent.add(new String[]{url, body, headers.get("X-IAM-Signature"), headers.get("X-IAM-Event")});
            if (failUrlContaining != null && url.contains(failUrlContaining)) return new Response(500, "HTTP 500");
            return status >= 200 && status < 300 ? new Response(status, null) : new Response(status, "HTTP " + status);
        }
    }

    static <T> T T(Supplier<T> s) { return Tx.run(s); }
    static void R(Runnable r) { Tx.run(r); }
    static void check(boolean ok, String msg) { checks++; if (!ok) { failures++; System.out.println("  FAIL: " + msg); } }
    static void eq(Object exp, Object act, String msg) {
        boolean ok;
        if (exp instanceof BigDecimal e && act instanceof BigDecimal a) ok = e.compareTo(a) == 0;
        else ok = Objects.equals(exp, act);
        check(ok, msg + " (expected <" + exp + "> but was <" + act + ">)");
    }
    static void section(String s) { System.out.println("== " + s); }
    static void rejects(String code, Runnable r, String msg) {
        try { Tx.run(r); check(false, msg + " (expected " + code + " but nothing was thrown)"); }
        catch (IamException e) { check(e.code().equals(code), msg + " (expected " + code + " but was " + e.code() + ": " + e.getMessage() + ")"); }
    }
    static long count(String sql, Object... args) { return jdbc.queryForObject(sql, Long.class, args); }
    static void ctx(String type, String name) { RequestContext.set(new RequestContext("corr-" + name, "10.0.0.9").as(type, name)); }

    static final String PW = "Str0ng-Passw0rd-One";
    static final String PW2 = "An0ther-Str0ng-Pass";

    static Instant now() { return clock.instant(); }
    static void advance(Duration d) { clock.advance(d); }
    static long audits(String action, String target) {
        return target == null ? count("SELECT count(*) FROM audit_log WHERE action = ?", action)
                : count("SELECT count(*) FROM audit_log WHERE action = ? AND target_id = ?", action, target);
    }
    static long audits(String action, String target, String outcome) {
        return count("SELECT count(*) FROM audit_log WHERE action = ? AND target_id = ? AND outcome = ?", action, target, outcome);
    }
    static long detailCount(String action, String target, String text) {
        return count("SELECT count(*) FROM audit_log WHERE action = ? AND target_id = ? AND position(? in detail) > 0", action, target, text);
    }
    static Authenticator.Result login(String u, String pw, String otp) { return T(() -> authenticator.login(u, pw, otp)); }

    /** The caller the API would see for this person, as if a token had just been issued. */
    static Caller person(String username, boolean withMfa) {
        AccessService.Snapshot s = T(() -> access.forUser(username).orElseThrow());
        return new Caller(username, s.kind(), s.permissions(), withMfa ? now() : null, now());
    }
    static Caller service(String clientId) {
        AccessService.Snapshot s = T(() -> access.forClient(clientId).orElseThrow());
        return new Caller(clientId, "SERVICE", s.permissions(), null, now());
    }

    static UserRow row(String username) { return T(() -> userRepo.findByUsername(username).orElseThrow()); }

    /** Creates a staff user, takes them through first sign-in (password change) and returns the chosen password. */
    static void staff(String username, String... roleCodes) {
        CreatedUser c = T(() -> userService.create(new CreateUserRequest(username, "STAFF", "User " + username, username + "@bank.test", null, null), "bootstrap"));
        eq("TEMPORARY_PASSWORD", c.secretKind(), "temp password issued for " + username);
        if (roleCodes.length > 0) {
            List<RoleGrantRequest> g = new ArrayList<>();
            for (String r : roleCodes) g.add(new RoleGrantRequest(r, null, null));
            T(() -> userService.assignRoles(c.user().id(), new AssignRolesRequest(g), "bootstrap"));
        }
        Authenticator.Result r = T(() -> authenticator.login(username, c.secret(), null));
        eq(Authenticator.Outcome.PASSWORD_CHANGE_REQUIRED, r.outcome(), username + " must change the temporary password");
        Tx.runKeeping(IamException.class, () -> { credentials.changeOwnPassword(username, c.secret(), PW); return null; });
    }

    /** Enrols MFA for the user and returns [secret, recovery codes...]. */
    static List<String> enrolMfa(String username) {
        MfaService.Enrolment e = T(() -> mfa.enrol(username));
        String code = totp.code(e.secret(), totp.stepAt(now()));
        List<String> recovery = T(() -> mfa.confirm(username, code));
        List<String> out = new ArrayList<>();
        out.add(e.secret());
        out.addAll(recovery);
        return out;
    }
    static String otp(String secret) { return totp.code(secret, totp.stepAt(now())); }

    static void wire() {
        clock = new MutableClock(Instant.now().truncatedTo(java.time.temporal.ChronoUnit.SECONDS));   // aligned with the database clock (column defaults use now())
        settings = new IamSettings();
        settings.bootstrapUsername = "bootstrap";
        settings.bootstrapPassword = "B00tstrap-Passw0rd!x";
        settings.allowHttpWebhooks = false;
        crypto = new SecretCrypto(fill(11));
        crypto2 = new SecretCrypto(fill(22));
        hasher = new SecretHasher() {
            public String hash(String raw) { return "{fake}" + new StringBuilder(raw).reverse() + "#" + Hashing.randomToken(4); }
            public boolean matches(String raw, String hash) { return hash != null && hash.startsWith("{fake}") && hash.substring(6, hash.lastIndexOf('#')).equals(new StringBuilder(raw).reverse().toString()); }
        };
        PasswordPolicy policy = new PasswordPolicy(12, 3, 5, 90, 365);
        LockoutPolicy lockout = new LockoutPolicy(5, Duration.ofMinutes(15));
        userRepo = new UserRepository(jdbc); rbacRepo = new RbacRepository(jdbc); clientRepo = new ClientRepository(jdbc); customerRepo = new CustomerRepository(jdbc);
        eventRepo = new EventRepository(jdbc); approvalRepo = new ApprovalRepository(jdbc); keyRepo = new KeyRepository(jdbc);
        audit = new AuditService(jdbc, clock);
        events = new EventService(eventRepo);
        consents = new ConsentService(customerRepo, userRepo, audit, events);
        authenticator = new Authenticator(userRepo, rbacRepo, policy, lockout, hasher, totp, crypto, consents, audit, MetricsSink.NOOP, clock);
        revocation = new RevocationService(userRepo, clientRepo, jdbc, clock);
        credentials = new CredentialService(userRepo, policy, hasher, audit, events, revocation, authenticator, consents, settings, clock);
        mfa = new MfaService(userRepo, rbacRepo, totp, crypto, audit, revocation, settings, clock);
        access = new AccessService(userRepo, rbacRepo, clientRepo, customerRepo, clock);
        authz = new AuthzService(access, rbacRepo, audit, MetricsSink.NOOP, settings, clock);
        webhooks = new WebhookService(eventRepo, crypto, audit, settings, clock);
        approvals = new ApprovalService(approvalRepo, access, authz, audit, events, webhooks, MetricsSink.NOOP, clock);
        userService = new UserService(userRepo, rbacRepo, customerRepo, credentials, mfa, revocation, approvals, access, audit, events, clock);
        selfService = new SelfService(userRepo, rbacRepo, access, consents, clock);
        roles = new RoleService(rbacRepo, userRepo, authz, access, audit, events, clock);
        clients = new ClientService(clientRepo, rbacRepo, hasher, revocation, access, audit, events, settings, clock);
        keys = new KeyService(keyRepo, crypto, audit, settings, clock);
        customers = new CustomerService(customerRepo, userRepo, access, audit, events, clock);
        bootstrap = new BootstrapService(userRepo, clientRepo, rbacRepo, hasher, policy, audit, revocation, settings, clock);
        dispatcher = new WebhookDispatcher(eventRepo, sender, crypto, settings, clock);
        sweep = new SweepService(approvals, keys, dispatcher, revocation, clock);
        reencrypt = new ReencryptService(jdbc, audit);
    }

    static byte[] fill(int v) { byte[] b = new byte[32]; Arrays.fill(b, (byte) v); return b; }

    public static void main(String[] args) throws Exception {
        jdbc = new PgJdbc();
        Tx.init(jdbc);
        wire();
        try {
            ctx("SYSTEM", "startup");
            Scenario1.run();
            Scenario2.run();
            Scenario3.run();
            Scenario1.passwordAge();
        } catch (Throwable t) {
            failures++;
            System.out.println("  CRASH: " + t);
            t.printStackTrace(System.out);
        } finally {
            jdbc.closeAll();
        }
        System.out.println(checks + " checks, " + failures + " failures");
        System.exit(failures == 0 ? 0 : 1);
    }
}
