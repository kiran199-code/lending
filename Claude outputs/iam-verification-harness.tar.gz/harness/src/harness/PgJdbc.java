package harness;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import org.springframework.jdbc.core.*;

import java.io.*;
import java.lang.reflect.Proxy;
import java.math.BigDecimal;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.*;
import java.util.*;

/** Local-only JdbcTemplate: one python/psycopg2 worker (= one real Postgres connection) per thread. */
public class PgJdbc extends JdbcTemplate {
    static final ObjectMapper M = new ObjectMapper();

    static class Worker {
        final Process proc; final BufferedWriter out; final BufferedReader in;
        Worker() throws IOException {
            proc = new ProcessBuilder("python3", System.getProperty("harness.worker", "/home/claude/iamsvc/harness/worker_iam.py")).redirectError(ProcessBuilder.Redirect.INHERIT).start();
            out = new BufferedWriter(new OutputStreamWriter(proc.getOutputStream()));
            in = new BufferedReader(new InputStreamReader(proc.getInputStream()));
        }
    }

    final List<Worker> all = Collections.synchronizedList(new ArrayList<>());
    final ThreadLocal<Worker> worker = ThreadLocal.withInitial(() -> { try { Worker w = new Worker(); all.add(w); return w; } catch (IOException e) { throw new RuntimeException(e); } });

    public void closeAll() { for (Worker w : all) w.proc.destroy(); }
    public void closeThread() { Worker w = worker.get(); w.proc.destroy(); all.remove(w); worker.remove(); }

    static ObjectNode arg(Object o) {
        ObjectNode n = M.createObjectNode();
        if (o == null) n.put("t", "null");
        else if (o instanceof BigDecimal b) { n.put("t", "num"); n.put("v", b.toPlainString()); }
        else if (o instanceof Long || o instanceof Integer) { n.put("t", "int"); n.put("v", o.toString()); }
        else if (o instanceof Boolean b) { n.put("t", "bool"); n.put("v", b); }
        else if (o instanceof LocalDate d) { n.put("t", "date"); n.put("v", d.toString()); }
        else { n.put("t", "str"); n.put("v", o.toString()); }
        return n;
    }

    JsonNode call(ObjectNode req) {
        Worker w = worker.get();
        try {
            w.out.write(M.writeValueAsString(req)); w.out.write("\n"); w.out.flush();
            JsonNode res = M.readTree(w.in.readLine());
            if (!res.get("ok").asBoolean()) {
                String err = res.get("error").asText();
                if (err.contains("duplicate key value violates unique constraint")) throw new org.springframework.dao.DuplicateKeyException(err);
                if (err.contains("violates check constraint") || err.contains("violates foreign key") || err.contains("violates not-null")) throw new org.springframework.dao.DataIntegrityViolationException(err);
                throw new SqlFailure(err, String.valueOf(req.get("sql")));
            }
            return res;
        } catch (IOException e) { throw new RuntimeException(e); }
    }

    public static class SqlFailure extends RuntimeException {
        public SqlFailure(String msg, String sql) { super("SQL failed: " + msg + "\n  in: " + sql); }
    }

    ObjectNode req(String op, String sql, Object[] args) {
        ObjectNode r = M.createObjectNode();
        r.put("op", op); r.put("sql", sql);
        ArrayNode a = r.putArray("args");
        if (args != null) for (Object o : args) a.add(arg(o));
        return r;
    }

    public void tx(String what) { call(M.createObjectNode().put("op", what)); }

    record Row(List<String> cols, JsonNode vals) {}

    static Object value(JsonNode v) {
        return switch (v.get("t").asText()) {
            case "null" -> null;
            case "num" -> new BigDecimal(v.get("v").asText());
            case "int" -> Long.parseLong(v.get("v").asText());
            case "bool" -> v.get("v").asBoolean();
            case "date" -> LocalDate.parse(v.get("v").asText());
            case "ts" -> OffsetDateTime.parse(v.get("v").asText().replace(" ", "T"));
            default -> v.get("v").asText();
        };
    }

    static ResultSet rs(Row row) {
        boolean[] wasNull = {false};
        return (ResultSet) Proxy.newProxyInstance(ResultSet.class.getClassLoader(), new Class<?>[]{ResultSet.class}, (p, m, a) -> {
            String n = m.getName();
            if (n.equals("wasNull")) return wasNull[0];
            if (n.startsWith("get")) {
                int idx;
                if (a[0] instanceof Integer i) idx = i - 1;
                else {
                    idx = row.cols.indexOf(((String) a[0]).toLowerCase());
                    if (idx < 0) throw new SQLException("no column " + a[0] + " in " + row.cols);
                }
                Object v = value(row.vals.get(idx));
                wasNull[0] = v == null;
                switch (n) {
                    case "getString": return v == null ? null : v.toString();
                    case "getLong": return v == null ? 0L : ((Number) v).longValue();
                    case "getInt": return v == null ? 0 : ((Number) v).intValue();
                    case "getBoolean": return v != null && (Boolean) v;
                    case "getBigDecimal": return v == null ? null : (v instanceof BigDecimal b ? b : new BigDecimal(v.toString()));
                    case "getObject": return v;
                }
            }
            throw new UnsupportedOperationException(n);
        });
    }

    List<Row> rows(JsonNode res) {
        List<String> cols = new ArrayList<>();
        for (JsonNode c : res.get("cols")) cols.add(c.asText().toLowerCase());
        List<Row> rows = new ArrayList<>();
        for (JsonNode r : res.get("rows")) rows.add(new Row(cols, r));
        return rows;
    }

    @Override public <T> List<T> query(String sql, RowMapper<T> mapper, Object... args) {
        List<T> out = new ArrayList<>();
        int i = 0;
        try { for (Row r : rows(call(req("query", sql, args)))) out.add(mapper.mapRow(rs(r), i++)); }
        catch (SQLException e) { throw new RuntimeException(e); }
        return out;
    }
    @Override public void query(String sql, RowCallbackHandler h, Object... args) {
        try { for (Row r : rows(call(req("query", sql, args)))) h.processRow(rs(r)); }
        catch (SQLException e) { throw new RuntimeException(e); }
    }
    @SuppressWarnings("unchecked")
    @Override public <T> T queryForObject(String sql, Class<T> type, Object... args) {
        List<Row> rows = rows(call(req("query", sql, args)));
        if (rows.isEmpty()) return null;
        Object v = value(rows.get(0).vals.get(0));
        if (v == null) return null;
        if (type == Long.class) return (T) Long.valueOf(((Number) v).longValue());
        if (type == Integer.class) return (T) Integer.valueOf(((Number) v).intValue());
        if (type == BigDecimal.class) return (T) (v instanceof BigDecimal ? v : new BigDecimal(v.toString()));
        if (type == String.class) return (T) v.toString();
        return (T) v;
    }
    @Override public <T> T queryForObject(String sql, RowMapper<T> m, Object... args) {
        List<T> l = query(sql, m, args);
        return l.isEmpty() ? null : l.get(0);
    }
    @Override public int update(String sql, Object... args) { return call(req("update", sql, args)).get("count").asInt(); }
    @Override public void execute(String sql) { call(req("update", sql, null)); }
}
