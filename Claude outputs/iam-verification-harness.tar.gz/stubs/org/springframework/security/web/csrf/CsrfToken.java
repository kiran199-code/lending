package org.springframework.security.web.csrf;
public interface CsrfToken extends java.io.Serializable { String getHeaderName(); String getParameterName(); String getToken(); }
