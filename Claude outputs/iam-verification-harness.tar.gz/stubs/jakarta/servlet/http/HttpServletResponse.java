package jakarta.servlet.http;
public interface HttpServletResponse extends jakarta.servlet.ServletResponse { void setHeader(String n, String v); void sendRedirect(String l) throws java.io.IOException; }
