package org.springframework.http.converter;
public class HttpMessageNotReadableException extends RuntimeException {}
