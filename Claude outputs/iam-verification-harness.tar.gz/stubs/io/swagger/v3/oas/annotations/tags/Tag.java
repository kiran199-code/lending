package io.swagger.v3.oas.annotations.tags;
import java.lang.annotation.*;
@Retention(RetentionPolicy.RUNTIME) public @interface Tag { String name(); String description() default ""; }
