package org.springframework.security.oauth2.server.authorization;
public final class OAuth2TokenType { public static final OAuth2TokenType ACCESS_TOKEN = new OAuth2TokenType(); public String getValue(){return "";} }
