package com.nimbusds.jose.jwk.source;
import com.nimbusds.jose.jwk.*; import com.nimbusds.jose.proc.SecurityContext;
public interface JWKSource<C extends SecurityContext> { java.util.List<JWK> get(JWKSelector s, C c) throws com.nimbusds.jose.KeySourceException; }
