package org.springframework.web.filter;
import jakarta.servlet.*; import jakarta.servlet.http.*; import java.io.IOException;
public abstract class OncePerRequestFilter {
  protected abstract void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain chain) throws ServletException, IOException;
}
